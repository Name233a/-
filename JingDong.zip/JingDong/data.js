// 左上角city的内容
const navCity = ['北京', '上海', '天津', '重庆', '河北', '山西', '河南', '辽宁', '吉林', '黑龙江', '内蒙古', '江苏', '山东', '安徽', '浙江', '福建', '湖北', '湖南', '广东', '广西', '江西', '四川', '海南', '贵州', '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆', '港澳', '台湾', '钓鱼岛', '海外'];
// 网址导航隐藏的内容的标题
const wwdt = ['特色主题', '行业频道', '生活服务', '更多精选'];
//网址导航隐藏的内容
const wwdh = {
    '特色主题': ['新品首发', '京东全融', '全球售', '台湾售', '俄语站', '装机大师', '港澳售', '优惠券', '秒杀', '印尼站', '陪伴计划', '出海招商', '拍拍二手'],
    '行业频道': ['手机', '智能数码', '电脑办公', '家用电器', '京东小家', '京东服饰', '京东生鲜', '母婴', '食品', '衣资频道', '整车', '图书', '劳动防护'],
    '生活服务': ['白条', '京东金融App', '京东小金库', '话费', '水电煤', '彩票', '旅行', '机票酒店', '电影票', '京东到家', '游戏', '拍拍回收'],
    '更多精选': ['合作招商', '京东通信', '京东E卡', '企业采购', '服务市场', '校园加盟', '知识产权维权', '京东安联保险', '京东数科保险', '京东零售云', '关于我们']
};
// input搜索框内的字
let inputArr = ["提升免疫", "京东京造", "低价电脑", "美妆护肤", "大虾片", "定制家具", "热卖潮品"];
// logo下面的小列表
var menuList = [{
    cate_menu_item: ["家用电器"],
    right: {
        cate_channe: ["家电馆", "开店设备一站购"],
        cate_detail: {
            cate_detail_ite1: {
                cate_detail_tit: ['电视'],
                cate_detail_con: ['全面屏电视', '教育电视', 'OLED电视', '智慧屏', '4K超清电视', '55英寸', '65英寸', '电视配件',]
            },
            cate_detail_ite2: {
                cate_detail_tit: ['空调'],
                cate_detail_con: ['新风空调', '以旧换新', '空调柜机', '空调套装', '空调挂机', '新一级能效', '挂机1.5匹', '柜机3匹', '变频空调', '中央空调', '移动空调']
            },
            cate_detail_ite3: {
                cate_detail_tit: ['洗衣机'],
                cate_detail_con: ['滚筒洗衣机', '洗烘一体机', '波轮洗衣机', '洗烘套装', '迷你洗衣机', '洗衣机配件', '烘干机']
            },
            cate_detail_ite4: {
                cate_detail_tit: ['冰箱'],
                cate_detail_con: ['多门', '对开门', '三门', '双门', '冰洗套装', '冷柜/冰吧', '酒柜', '冰箱配件']
            },
            cate_detail_ite5: {
                cate_detail_tit: ['厨卫大电'],
                cate_detail_con: ['油烟机', '灶具', '烟灶套装', '集成灶', '集成水槽', '消毒柜', '洗碗机', '电热水器', '燃气热水器', '壁挂炉', '空气能热水器', '嵌入式厨电', '太阳能热水器', '烟机灶具配件']
            },
            cate_detail_ite6: {
                cate_detail_tit: ['厨房小电'],
                cate_detail_con: ['破壁机', '咖啡机', '榨汁机', '电炖锅', '果蔬净化清洗机', '三明治机/早餐机', '电烤箱', '厨师机/和面机', '料理机', '电饼铛', '电水壶/热水瓶', '面包机', '电火锅', '空气炸锅', '养生壶', '电磁炉', '电饭煲', '电压力锅', '微波炉', '面条机', '电陶炉', '电烧烤炉', '煮蛋器', '电热饭盒', '豆浆机']
            },
            cate_detail_ite7: {
                cate_detail_tit: ['环境电器'],
                cate_detail_con: ['电风扇', '冷风扇', '空气净化器', '加湿器', '净水器', '饮水机', '茶吧机', '除湿机', '电话机', '取暖器', '生活电器配件']
            },
            cate_detail_item8: {
                cate_detail_tit: ['个护健康'],
                cate_detail_con: ['剃须刀', '电动牙刷', '冲牙器', '电吹风', '卷/直发器', '理发器', '美容仪', '剃/脱毛器', '洁面仪', '按摩器', '按摩椅', '足浴盆', '挂烫机/熨斗', '电动牙刷头', '干衣机', '毛球修剪器']
            },
            cate_detail_item9: {
                cate_detail_tit: ['清洁电器'],
                cate_detail_con: ['吸尘器', '扫地机器人', '擦地/擦窗机器人', '蒸汽/电动拖把', '除螨仪', '洗地机']
            },
            cate_detail_item10: {
                cate_detail_tit: ['视听影音'],
                cate_detail_con: ['家庭影院', 'KTV音响', '迷你音响', 'DVD', '功放', '回音壁', '麦克风']
            }
        }
    }
}, {
    cate_menu_item: ['手机', '运营商', '数码'],
    right: {
        cate_channe: ['手机频道', '网上营业厅', '配件频道', '智能数码', '影像Club'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['手机通讯'],
                cate_detail_con: ['手机', '游戏手机', '5G手机', '拍照手机', '全面屏手机', '对讲机', '以旧换新', '手机维修']
            },
            cate_detail_item2: {
                cate_detail_tit: ['运营商'],
                cate_detail_con: ['合约机', '手机卡', '宽带', '充话费/流量', '中国电信', '中国移动', '中国联通', '京东通信', '挑靓号']
            },
            cate_detail_item3: {
                cate_detail_tit: ['手机配件'],
                cate_detail_con: ['手机壳', '贴膜', '手机存储卡', '数据线', '充电器', '手机耳机', '创意配件', '手机饰品', '手机电池', '苹果周边', '移动电源', '蓝牙耳机', '手机支架', '拍照配件']
            },
            cate_detail_item4: {
                cate_detail_tit: ['摄影摄像'],
                cate_detail_con: ['数码相机', '微单相机', '单反相机', '拍立得', '运动相机', '摄像机', '镜头', '户外器材', '影棚器材', '冲印服务', '数码相框']
            },
            cate_detail_item5: {
                cate_detail_tit: ['数码配件'],
                cate_detail_con: ['存储卡', '三脚架/云台', '相机包', '滤镜', '闪光灯/手柄', '相机清洁/贴膜', '机身附件', '镜头附件', '读卡器', '支架', '电池/充电器', '运动相机配件']
            },
            cate_detail_item6: {
                cate_detail_tit: ['影音娱乐'],
                cate_detail_con: ['耳机/耳麦', '音箱/音响', '智能音箱', '收音机', '麦克风', 'MP3/MP4', '专业音频', '音频线']
            },
            cate_detail_item7: {
                cate_detail_tit: ['智能设备'],
                cate_detail_con: ['智能手表', '智能手环', '监控摄像', '智能出行', '智能眼镜', '智能家居', '健康监测', '无人机', '智能机器人', '智能配饰', '运动跟踪器', '智能儿童手表', 'AR/VR配件']
            },
            cate_detail_item8: {
                cate_detail_tit: ['电子教育'],
                cate_detail_con: ['学生平板', '点读机/笔', '早教益智', '录音笔', '电纸书', '电子词典', '复读机', '翻译机']
            },
        }
    }
}, {
    cate_menu_item: ['电脑', '办公'],
    right: {
        cate_channe: ['电脑办公', '企业采购', 'GAME', '装机大师', '企业租赁'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['电脑整机'],
                cate_detail_con: ['笔记本', '游戏本', '平板电脑', '台式机', '一体机', '服务器/工作站']
            },
            cate_detail_item2: {
                cate_detail_tit: ['电脑配件'],
                cate_detail_con: ['显示器', 'CPU', '主板', '显卡', '硬盘', '内存', '机箱', '电源', '散热器', '显示器支架', '刻录机/光驱', '声卡/扩展卡', '装机配件', 'SSD固态硬盘', '组装电脑', 'USB分线器', '主板CPU套装']
            },
            cate_detail_item3: {
                cate_detail_tit: ['外设产品'],
                cate_detail_con: ['鼠标', '键盘', '键鼠套装', '网络仪表仪器', 'U盘', '移动固态硬盘', '移动硬盘', '鼠标垫', '摄像头', '线缆', '手写板', '硬盘盒', '电脑工具', '电脑清洁', 'UPS电源', '插座', '平板电脑配件', '笔记本配件', '投屏器', '扩展坞', '键帽']
            },
            cate_detail_item4: {
                cate_detail_tit: ['游戏设备'],
                cate_detail_con: ['游戏机', '游戏耳机', '手柄/方向盘', '游戏软件', '游戏周边']
            },
            cate_detail_item5: {
                cate_detail_tit: ['网络产品'],
                cate_detail_con: ['路由器', '网络机顶盒', '交换机', '网络存储', '网卡', '5G/4G上网', '网线', '网络配件']
            },
            t6: {
                cate_detail_tit: ['办公设备'],
                cate_detail_con: ['投影机', '投影配件', '打印机', '传真设备', '验钞/点钞机', '扫描设备', '复合机', '碎纸机', '考勤门禁', '收银机', '会议音频视频', '保险柜', '装订/封装机', '安防监控', '白板']
            },
            cate_detail_item7: {
                cate_detail_tit: ['文具'],
                cate_detail_con: ['笔类', '本册/便签', '办公文具', '文件收纳', '学生文具', '计算器', '画具画材', '财会用品', '文房四宝']
            },
            cate_detail_item8: {
                cate_detail_tit: ['耗材'],
                cate_detail_con: ['硒鼓/墨粉', '墨盒', '色带', '纸类', '刻录光盘']
            },
            cate_detail_item9: {
                cate_detail_tit: ['服务产品'],
                cate_detail_con: ['延保服务', '上门安装', '维修保养', '电脑软件']
            },
        }
    }
}, {
    cate_menu_item: ['家居', '家具', '家装', '厨具'],
    right: {
        cate_channe: ['家装城', '居家日用', '精品家具', '家装建材', '国际厨具', '装修服务', '企业采购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['厨具'],
                cate_detail_con: ['水具酒具', '烹饪锅具', '炒锅', '碗碟套装', '厨房配件', '刀剪菜板', '锅具套装', '茶具', '咖啡具', '保温杯', '厨房置物架']
            },
            cate_detail_item2: {
                cate_detail_tit: ['家纺'],
                cate_detail_con: ['四件套', '枕芯', '毛巾浴巾', '地毯地垫', '床垫/床褥', '毯子', '抱枕靠垫', '窗帘/窗纱', '床单/床笠', '被套', '枕巾枕套', '沙发垫套', '坐垫', '桌布/罩件', '蚕丝被', '乳胶枕', '蚊帐', '凉席', '夏被']
            },
            cate_detail_item3: {
                cate_detail_tit: ['生活日用'],
                cate_detail_con: ['收纳用品', '雨伞雨具', '净化除味', '浴室用品', '洗晒/熨烫', '缝纫/针织用品', '保暖防护']
            },
            cate_detail_item4: {
                cate_detail_tit: ['家装软饰'],
                cate_detail_con: ['装饰字画', '装饰摆件', '手工/十字绣', '相框/照片墙', '墙贴/装饰贴', '花瓶花艺', '香薰蜡烛', '节庆饰品', '钟饰', '帘艺隔断', '创意家居', '3D立体墙贴', '玻璃贴纸', '电视背景墙', '电表箱装饰画']
            },
            cate_detail_item5: {
                cate_detail_tit: ['灯具'],
                cate_detail_con: ['吸顶灯', '吊灯', '台灯', '筒灯射灯', '庭院灯', '装饰灯', 'LED灯', '氛围照明', '落地灯', '应急灯/手电', '节能灯']
            },
            cate_detail_item6: {
                cate_detail_tit: ['家具'],
                cate_detail_con: ['客厅', '卧室', '餐厅', '书房', '儿童', '储物', '办公家具', '阳台户外', '电脑桌', '电视柜', '茶几', '办公柜', '沙发', '床', '床垫', '餐桌', '衣柜', '书架', '鞋柜', '置物架', '电脑椅', '晾衣架', '儿童床', '儿童桌椅', '红木']
            },
            cate_detail_item7: {
                cate_detail_tit: ['全屋定制'],
                cate_detail_con: ['定制衣柜', '榻榻米', '橱柜', '门', '室内门', '防盗门', '窗', '淋浴房', '壁挂炉', '散热器']
            },
            cate_detail_item8: {
                cate_detail_tit: ['建筑材料'],
                cate_detail_con: ['油漆涂料', '涂刷辅料', '瓷砖', '地板', '壁纸', '强化地板', '美缝剂', '防水涂料', '木材/板材']
            },
            cate_detail_item9: {
                cate_detail_tit: ['厨房卫浴'],
                cate_detail_con: ['水槽', '龙头', '淋浴花洒', '马桶', '智能马桶', '智能马桶盖', '厨卫挂件', '浴室柜', '浴霸', '集成吊顶', '垃圾处理器', '厨卫配件']
            },
            cate_detail_item10: {
                cate_detail_tit: ['五金电工'],
                cate_detail_con: ['指纹锁', '电动工具', '手动工具', '测量工具', '工具箱', '开关插座', '配电箱/断路器', '机械锁', '拉手']
            },
            cate_detail_item11: {
                cate_detail_tit: ['装修设计'],
                cate_detail_con: ['全包装修', '半包装修', '家装设计', '高端设计', '局部装修', '安装服务', '装修公司', '旧房翻新']
            },

        }
    }
}, {
    cate_menu_item: ['男装', '女装', '童装', '内衣'],
    right: {
        cate_channe: ['男装', '女装', '内衣', '童装童鞋', '服饰企业购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['女装'],
                cate_detail_con: ['当季热卖', '新品推荐', '商场同款', '时尚套装', '连衣裙', '半身裙', 'T恤', '衬衫', '休闲裤', '牛仔裤', '短外套', '卫衣', '小西装', '风衣', '针织衫', '雪纺衫', '大码女装', '中老年女装', '短裤', '正装裤', '马甲', '吊带/背心', '打底衫', '旗袍/汉服', '礼服', '婚纱', '毛衣', '羊绒衫', '羽绒服', '毛呢大衣', '棉服', '皮草', '仿皮皮衣', '真皮皮衣', '打底裤', '加绒裤', '设计师/潮牌']
            },
            cate_detail_item2: {
                cate_detail_tit: ['男装'],
                cate_detail_con: ['新品推荐', 'T恤', '牛仔裤', '休闲裤', '衬衫', '短裤', 'POLO衫', '羽绒服', '棉服', '真皮皮衣', '夹克', '卫衣', '毛呢大衣', '大码男装', '西服套装', '仿皮皮衣', '风衣', '针织衫', '马甲/背心', '羊毛衫', '羊绒衫', '西服', '西裤', '卫裤/运动裤', '工装', '设计师/潮牌', '唐装/中山装', '中老年男装', '加绒裤']
            },
            cate_detail_item3: {
                cate_detail_tit: ['内衣'],
                cate_detail_con: ['文胸', '睡衣/家居服', '男士内裤', '女士内裤', '吊带/背心', '文胸套装', '情侣睡衣', '塑身美体', '少女文胸', '休闲棉袜', '商务男袜', '连裤袜/丝袜', '美腿袜', '打底裤袜', '抹胸', '内衣配件', '大码内衣', '打底衫', '泳衣', '秋衣秋裤', '保暖内衣']
            },
            cate_detail_item4: {
                cate_detail_tit: ['配饰'],
                cate_detail_con: ['女士围巾/披肩', '光学镜架/镜片', '毛线帽', '真皮手套', '毛线手套', '男士丝巾/围巾', '棒球帽', '太阳镜', '防辐射眼镜', '老花镜', '贝雷帽', '礼帽', '围巾/手套/帽子套装', '领带/领结/领带夹', '鸭舌帽', '口罩', '耳罩/耳包', '毛线/布面料', '遮阳帽', '遮阳伞/雨伞', '袖扣', '钥匙扣', '游泳镜', '男士腰带/礼盒', '女士腰带/礼盒']
            },
            cate_detail_item5: {
                cate_detail_tit: ['童装'],
                cate_detail_con: ['套装', '卫衣', '裤子', '外套/大衣', '毛衣/针织衫', '衬衫', '户外/运动服', 'T恤', '裙子', '亲子装', '礼服/演出服', '羽绒服', '棉服', '内衣裤', '配饰', '家居服', '马甲', '袜子', '民族服装', '婴儿礼盒', '连体衣/爬服']
            },
            cate_detail_item6: {
                cate_detail_tit: ['童鞋'],
                cate_detail_con: ['运动鞋', '靴子', '帆布鞋', '皮鞋', '棉鞋', '凉鞋', '拖鞋']
            },

        }
    }
}, {
    cate_menu_item: ['美妆', '个护清洁', '宠物'],
    right: {
        cate_channe: ['清洁用品', '美妆馆', '个护馆', '妆比社', '京东国际美妆', '宠物馆', '美妆企业购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['面部护肤'],
                cate_detail_con: ['礼盒', '美白', '防晒', '面膜', '洁面', '爽肤水', '精华', '眼霜', '乳液/面霜', '卸妆', 'T区护理', '润唇膏']
            },
            cate_detail_item2: {
                cate_detail_tit: ['香水彩妆'],
                cate_detail_con: ['隔离', '遮瑕', '气垫BB', '粉底', '腮红', '口红/唇膏', '唇釉/唇彩', '睫毛膏', '眼影', '眼线', '眉笔/眉粉', '散粉', '美甲', '女士香水', '男士香水', '彩妆工具', '男士彩妆', '彩妆套装']
            },
            cate_detail_item3: {
                cate_detail_tit: ['男士护肤'],
                cate_detail_con: ['控油', '洁面', '乳液/面霜', '面膜', '爽肤水', '剃须', '精华', '防晒', '套装/礼盒']
            },
            cate_detail_item4: {
                cate_detail_tit: ['洗发护发'],
                cate_detail_con: ['洗发水', '护发素', '发膜/精油', '造型', '染发', '烫发', '假发', '美发工具', '洗护套装']
            },
            cate_detail_item5: {
                cate_detail_tit: ['口腔护理'],
                cate_detail_con: ['牙膏', '牙粉', '牙贴', '牙刷', '牙线', '漱口水', '口喷', '假牙清洁', '套装']
            },
            cate_detail_item6: {
                cate_detail_tit: ['身体护理'],
                cate_detail_con: ['花露水', '沐浴露', '香皂', '洗手液', '护手霜', '浴盐', '润肤', '精油', '美颈', '美胸', '纤体塑形', '手膜/足膜', '男士洗液', '走珠/止汗露', '脱毛刀/膏', '套装']
            },
            cate_detail_item7: {
                cate_detail_tit: ['女性护理'],
                cate_detail_con: ['卫生巾', '卫生棉条', '卫生护垫', '私处护理']
            },
            cate_detail_item8: {
                cate_detail_tit: ['纸品清洗'],
                cate_detail_con: ['抽纸', '卷纸', '湿巾', '厨房用纸', '湿厕纸', '洗衣凝珠', '洗衣液', '洗衣粉', '肥皂', '护理除菌']
            },
            cate_detail_item9: {
                cate_detail_tit: ['家庭清洁'],
                cate_detail_con: ['洗洁精', '油污净', '洁厕剂', '消毒液', '地板清洁剂', '垃圾袋', '垃圾桶', '拖把/扫把', '驱蚊驱虫']
            },
            cate_detail_item10: {
                cate_detail_tit: ['宠物生活'],
                cate_detail_con: ['狗粮', '狗罐头', '狗零食', '狗厕所', '尿垫', '猫粮', '猫罐头', '猫零食', '猫砂', '猫砂盆', '猫狗窝', '食具水具', '医疗保健', '宠物玩具', '宠物鞋服', '洗护美容', '宠物牵引', '小宠用品', '水族世界', '鱼缸/水族箱', '鱼粮/饲料', '水族活体']
            },

        }
    }
}, {
    cate_menu_item: ['女鞋', '箱包', '钟表', '珠宝'],
    right: {
        cate_channe: ['自营箱包', '时尚鞋包', '潮流珠宝', '奢侈品', '黄金企业购', '鞋包企业购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['时尚女鞋'],
                cate_detail_con: ['新品推荐', '休闲鞋', '凉鞋', '单鞋', '拖鞋/人字拖', '高跟鞋', '妈妈鞋', '帆布鞋', '布鞋/绣花鞋', '内增高', '雨鞋/雨靴', '女靴', '雪地靴', '鱼嘴鞋', '马丁靴', '踝靴', '松糕鞋', '坡跟鞋', '防水台', '鞋配件']
            },
            cate_detail_item2: {
                cate_detail_tit: ['潮流女包'],
                cate_detail_con: ['单肩包', '手提包', '斜挎包', '双肩包', '钱包', '手拿包', '卡包/零钱包', '钥匙包']
            },
            cate_detail_item3: {
                cate_detail_tit: ['精品男包'],
                cate_detail_con: ['男士钱包', '双肩包', '单肩/斜挎包', '商务公文包', '男士手包', '卡包名片夹', '钥匙包']
            },
            cate_detail_item4: {
                cate_detail_tit: ['功能箱包'],
                cate_detail_con: ['拉杆箱', '拉杆包', '旅行包', '电脑包', '休闲运动包', '书包', '登山包', '腰包/胸包', '旅行配件']
            },
            cate_detail_item5: {
                cate_detail_tit: ['奢侈品'],
                cate_detail_con: ['箱包', '钱包', '服饰', '腰带', '鞋靴', '太阳镜/眼镜框', '饰品', '配件']
            },
            cate_detail_item6: {
                cate_detail_tit: ['精选大牌'],
                cate_detail_con: ['GUCCI', 'COACH', '雷朋', '施华洛世奇', 'MK', '阿玛尼', '菲拉格慕', 'VERSACE', '普拉达', '巴宝莉', '万宝龙']
            },
            cate_detail_item7: {
                cate_detail_tit: ['钟表'],
                cate_detail_con: ['DW', '天梭', '浪琴', '欧米茄', '萧邦', '阿玛尼', '卡西欧', '西铁城', '天王', '瑞表', '国表', '日韩表', '欧美表', '德表', '儿童手表', '智能手表', '闹钟', '挂钟', '座钟', '钟表配件', '钟表维修']
            },
            cate_detail_item8: {
                cate_detail_tit: ['珠宝首饰'],
                cate_detail_con: ['黄金', 'K金', '时尚饰品', '钻石', '翡翠', '和田玉', '银饰', '水晶玛瑙', '彩宝', '铂金', '木手串/把件', '珍珠', '发饰']
            },
            cate_detail_item9: {
                cate_detail_tit: ['金银投资'],
                cate_detail_con: ['投资金', '投资银', '投资收藏']
            },
        }
    }
}, {
    cate_menu_item: ['男鞋', '运动', '户外'],
    right: {
        cate_channe: ['体育服务', '运动城', '户外馆', '健身房', '骑行馆', '钟表城', '钟表企业购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['流行男鞋'],
                cate_detail_con: ['新品推荐', '休闲鞋', '凉鞋', '商务休闲鞋', '正装鞋', '帆布鞋', '拖鞋', '功能鞋', '传统布鞋', '增高鞋', '男靴', '雨鞋', '工装鞋', '鞋配件']
            },
            cate_detail_item2: {
                cate_detail_tit: ['运动鞋包'],
                cate_detail_con: ['跑步鞋', '休闲鞋', '篮球鞋', '帆布鞋', '板鞋', '拖鞋', '运动包', '足球鞋', '专项运动鞋', '训练鞋']
            },
            cate_detail_item3: {
                cate_detail_tit: ['运动服饰'],
                cate_detail_con: ['T恤', '运动裤', '运动套装', '夹克/风衣', '运动配饰', '卫衣/套头衫', '运动背心', '健身服', '运动内衣', '羽绒服', '棉服']
            },
            cate_detail_item4: {
                cate_detail_tit: ['健身训练'],
                cate_detail_con: ['跑步机', '动感单车', '健身车', '椭圆机', '综合训练器', '划船机', '甩脂机', '倒立机', '踏步机', '哑铃', '仰卧板/收腹机', '瑜伽用品', '舞蹈用品', '运动护具', '健腹轮', '拉力器/臂力器', '跳绳', '引体向上器']
            },
            cate_detail_item5: {
                cate_detail_tit: ['骑行运动'],
                cate_detail_con: ['山地车', '公路车', '折叠车', '骑行服', '城市自行车', '穿戴装备', '自行车配件']
            },
            cate_detail_item6: {
                cate_detail_tit: ['体育用品'],
                cate_detail_con: ['乒乓球', '羽毛球', '篮球', '足球', '轮滑滑板', '网球', '高尔夫', '台球', '排球', '棋牌麻将', '民俗运动', '体育服务', '田径鞋']
            },
            cate_detail_item7: {
                cate_detail_tit: ['户外鞋服'],
                cate_detail_con: ['户外风衣', '徒步鞋', 'T恤', '冲锋衣裤', '速干衣裤', '越野跑鞋', '滑雪服', '羽绒服/棉服', '休闲衣裤', '抓绒衣裤', '溯溪鞋', '沙滩/凉拖', '休闲鞋', '软壳衣裤', '功能内衣', '军迷服饰', '登山鞋', '工装鞋', '户外袜', '户外防晒衣']
            },
            cate_detail_item8: {
                cate_detail_tit: ['户外装备'],
                cate_detail_con: ['背包', '帐篷/垫子', '望远镜', '烧烤用具', '便携桌椅床', '户外配饰', '军迷用品', '野餐用品', '睡袋/吊床', '救援装备', '户外照明', '旅行装备', '户外工具', '户外仪表', '登山攀岩', '极限户外', '冲浪潜水', '滑雪装备']
            },
            cate_detail_item9: {
                cate_detail_tit: ['垂钓用品'],
                cate_detail_con: ['钓竿', '鱼线', '浮漂', '鱼饵', '钓鱼配件', '渔具包', '钓箱钓椅', '鱼线轮', '钓鱼灯', '辅助装备']
            },
            cate_detail_item10: {
                cate_detail_tit: ['游泳用品'],
                cate_detail_con: ['女士泳衣', '比基尼', '男士泳衣', '泳镜', '游泳圈', '游泳包防水包', '泳帽', '游泳配件']
            },
        }
    }
}, {
    cate_menu_item: ['房产', '汽车', '汽车用品'],
    right: {
        cate_channe: ['全新汽车', '车管家', '旗舰店', '新车装备', '直营店', '油卡充值'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['房产'],
                cate_detail_con: ['最新开盘', '别墅', '商业办公', '普通住宅', '文旅地产', '长租公寓']
            },
            cate_detail_item2: {
                cate_detail_tit: ['汽车车型'],
                cate_detail_con: ['微型车', '小型车', '紧凑型车', '中型车', '中大型车', '豪华车', 'MPV', 'SUV', '跑车']
            },
            cate_detail_item3: {
                cate_detail_tit: ['汽车价格'],
                cate_detail_con: ['5-8万', '8-12万', '12-18万', '18-25万', '25-40万', '40万以上']
            },
            cate_detail_item4: {
                cate_detail_tit: ['汽车品牌'],
                cate_detail_con: ['大众', '日产', '丰田', '别克', '宝骏', '本田']
            },
            cate_detail_item5: {
                cate_detail_tit: ['维修保养'],
                cate_detail_con: ['京东保养', '汽机油', '轮胎', '添加剂', '防冻液', '滤清器', '蓄电池', '变速箱油/滤', '雨刷', '刹车片/盘', '火花塞', '车灯', '轮毂', '维修配件', '汽车玻璃', '减震器', '正时皮带', '汽车喇叭', '汽修工具', '改装配件', '原厂件', '底盘装甲/护板']
            },
            cate_detail_item6: {
                cate_detail_tit: ['汽车装饰'],
                cate_detail_con: ['座垫座套', '脚垫', '头枕腰靠', '方向盘套', '后备箱垫', '车载支架', '车钥匙扣', '香水', '炭包/净化剂', '扶手箱', '挂件摆件', '车用收纳袋/盒', '遮阳/雪挡', '车衣', '车贴', '踏板', '行李架/箱', '雨眉', '汽车窗帘', '导航/中控膜', '功能小件', '车身装饰件']
            },
            cate_detail_item7: {
                cate_detail_tit: ['车载电器'],
                cate_detail_con: ['行车记录仪', '车载充电器', '车机导航', '车载蓝牙', '智能驾驶', '对讲电台', '倒车雷达', '导航仪', '安全预警仪', '车载净化器', '车载吸尘器', '汽车音响', '车载冰箱', '应急电源', '逆变器', '车载影音', '车载生活电器', '车载电器配件']
            },
            cate_detail_item8: {
                cate_detail_tit: ['美容清洗'],
                cate_detail_con: ['洗车机', '洗车水枪', '玻璃水', '清洁剂', '镀晶镀膜', '车蜡', '汽车贴膜', '补漆笔', '毛巾掸子', '隐形车衣', '汽车改色膜']
            },
            cate_detail_item9: {
                cate_detail_tit: ['安全自驾'],
                cate_detail_con: ['胎压监测', '充气泵', '灭火器', '车载床', '应急救援', '防盗设备', '自驾野营', '保温箱', '储物箱', 'GPS定位器']
            },
            cate_detail_item10: {
                cate_detail_tit: ['汽车服务'],
                cate_detail_con: ['保养维修', '洗车', '钣金喷漆', '清洗美容', '功能升级', '改装服务', 'ETC', '驾驶培训', '油卡充值', '加油卡']
            },
            cate_detail_item11: {
                cate_detail_tit: ['电动车'],
                cate_detail_con: ['电动自行车', '电动摩托车', '电动轻便摩托车', '平衡车', '电动滑板车', '电动三轮车', '电动车装备', '电动车零配件', '老年代步车']
            },
            cate_detail_item12: {
                cate_detail_tit: ['摩托车'],
                cate_detail_con: ['摩托车', '摩托车养护', '摩托车手套', '摩托车护具', '摩托车骑行服', '摩托车蓝牙装备', '摩托车头盔', '其它摩托车装备', '摩托车骑行鞋', '骑士包', '摩托车雨衣', '摩托车风镜']
            },
        }
    }
}, {
    cate_menu_item: ['母婴', '玩具乐器'],
    right: {
        cate_channe: ['母婴', '玩具乐器', '奶粉馆', '尿裤馆', '京东国际母婴'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['奶粉'],
                cate_detail_con: ['1段', '2段', '3段', '4段', '孕妈奶粉', '特殊配方奶粉', '有机奶粉']
            },
            cate_detail_item2: {
                cate_detail_tit: ['营养辅食'],
                cate_detail_con: ['米粉/菜粉', '面条/粥', '果泥/果汁', '益生菌/初乳', 'DHA', '钙铁锌/维生素', '清火/开胃', '宝宝零食']
            },
            cate_detail_item3: {
                cate_detail_tit: ['尿裤湿巾'],
                cate_detail_con: ['拉拉裤', '成人尿裤', '婴儿湿巾']
            },
            cate_detail_item4: {
                cate_detail_tit: ['喂养用品'],
                cate_detail_con: ['奶瓶奶嘴', '吸奶器', '暖奶消毒', '辅食料理机', '牙胶安抚', '食物存储', '儿童餐具', '水壶/水杯', '围兜/防溅衣']
            },
            cate_detail_item5: {
                cate_detail_tit: ['洗护用品'],
                cate_detail_con: ['宝宝护肤', '日常护理', '洗发沐浴', '洗澡用具', '洗衣液/皂', '理发器', '婴儿口腔清洁', '座便器', '驱蚊防晒']
            },
            cate_detail_item6: {
                cate_detail_tit: ['寝居服饰'],
                cate_detail_con: ['睡袋/抱被', '婴儿枕', '毛毯棉被', '婴童床品', '浴巾/浴衣', '毛巾/口水巾', '婴儿礼盒', '婴儿内衣', '婴儿外出服', '隔尿垫巾', '尿布', '安全防护', '爬行垫', '婴儿鞋帽袜']
            },
            cate_detail_item7: {
                cate_detail_tit: ['妈妈专区'],
                cate_detail_con: ['防辐射服', '孕妈装', '孕妇护肤', '妈咪包/背婴带', '待产护理', '产后塑身', '文胸/内裤', '防溢乳垫', '孕期营养']
            },
            cate_detail_item8: {
                cate_detail_tit: ['童车童床'],
                cate_detail_con: ['安全座椅', '婴儿推车', '婴儿床', '婴儿床垫', '餐椅', '摇椅', '学步车', '三轮车', '自行车', '扭扭车', '滑板车', '电动车']
            },
            cate_detail_item9: {
                cate_detail_tit: ['玩具'],
                cate_detail_con: ['益智玩具', '健身/戏水', '橡皮泥', '绘画/DIY', '积木拼装', '遥控/电动', '毛绒玩具', '娃娃玩具', '动漫玩具', '模型玩具', '创意减压', 'STEAM/科学实验玩具', '潮流盲盒', '高达/变形模型']
            },
            cate_detail_item10: {
                cate_detail_tit: ['乐器'],
                cate_detail_con: ['钢琴', '电钢琴', '电子琴', '吉他', '尤克里里', '打击乐器', '西洋管弦', '民族乐器', '乐器配件']
            },

        }
    }
}, {
    cate_menu_item: ['食品', '酒类', '生鲜', '特产'],
    right: {
        cate_channe: ['生鲜', '食品饮料', '酒类', '地方特产', '京东国际美食'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['新鲜水果'],
                cate_detail_con: ['苹果', '橙子', '奇异果/猕猴桃', '火龙果', '榴莲', '芒果', '椰子', '车厘子', '百香果', '柚子', '国产水果', '进口水果']
            },
            cate_detail_item2: {
                cate_detail_tit: ['蔬菜蛋品'],
                cate_detail_con: ['蛋品', '叶菜类', '根茎类', '葱姜蒜椒', '鲜菌菇', '茄果瓜类', '半加工蔬菜', '半加工豆制品', '玉米', '山药', '地瓜/红薯']
            },
            cate_detail_item3: {
                cate_detail_tit: ['精选肉类'],
                cate_detail_con: ['猪肉', '牛肉', '羊肉', '鸡肉', '鸭肉', '冷鲜肉', '特色肉类', '内脏类', '冷藏熟食', '牛排', '牛腩', '鸡翅']
            },
            cate_detail_item4: {
                cate_detail_tit: ['海鲜水产'],
                cate_detail_con: ['鱼类', '虾类', '蟹类', '贝类', '海参', '鱿鱼/章鱼', '活鲜', '三文鱼', '大闸蟹', '小龙虾', '海鲜加工品', '海产干货']
            },
            cate_detail_item5: {
                cate_detail_tit: ['冷饮冻食'],
                cate_detail_con: ['水饺/馄饨', '汤圆/元宵', '面点', '奶酪/黄油', '方便速食', '火锅丸串', '冰淇淋', '冷藏饮料', '低温奶', '生日蛋糕']
            },
            cate_detail_item6: {
                cate_detail_tit: ['中外名酒'],
                cate_detail_con: ['白酒', '葡萄酒', '洋酒', '啤酒', '黄酒/养生酒', '收藏酒/陈年老酒']
            },
            cate_detail_item7: {
                cate_detail_tit: ['进口食品'],
                cate_detail_con: ['牛奶', '饼干蛋糕', '糖/巧克力', '零食', '水', '饮料', '咖啡粉', '冲调品', '油', '方便食品', '米面调味']
            },
            cate_detail_item8: {
                cate_detail_tit: ['休闲食品'],
                cate_detail_con: ['中华老字号', '营养零食', '休闲零食', '膨化食品', '坚果炒货', '蜜饯果干', '糖果/巧克力', '饼干蛋糕', '粽子']
            },
            cate_detail_item9: {
                cate_detail_tit: ['地方特产'],
                cate_detail_con: ['北京', '新疆', '陕西', '云南', '山东', '广西']
            },
            cate_detail_item10: {
                cate_detail_tit: ['茗茶'],
                cate_detail_con: ['铁观音', '普洱', '龙井', '绿茶', '红茶', '乌龙茶', '茉莉花茶', '花草茶', '花果茶', '黑茶', '白茶', '养生茶', '其他茶']
            },
            cate_detail_item11: {
                cate_detail_tit: ['饮料冲调'],
                cate_detail_con: ['饮料', '牛奶酸奶', '饮用水', '咖啡/奶茶', '蜂蜜/蜂产品', '冲饮谷物', '成人奶粉']
            },
            cate_detail_item12: {
                cate_detail_tit: ['粮油调味'],
                cate_detail_con: ['大米', '食用油', '面', '杂粮', '调味品', '南北干货', '方便食品', '烘焙原料', '有机食品']
            },
        }
    }
}, {
    cate_menu_item: ['艺术', '礼品鲜花', '农资绿植'],
    right: {
        cate_channe: ['京东礼品', '火机烟具', '鲜花', '京东农服', '同城绿植', '园林园艺'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['艺术品'],
                cate_detail_con: ['油画', '版画', '水墨画', '书法', '雕塑', '艺术画册', '艺术衍生品']
            },
            cate_detail_item2: {
                cate_detail_tit: ['火机烟具'],
                cate_detail_con: ['打火机', '烟嘴', '烟盒', '烟斗']
            },
            cate_detail_item3: {
                cate_detail_tit: ['礼品'],
                cate_detail_con: ['创意礼品', '电子礼品', '工艺礼品', '美妆礼品', '婚庆节庆', '礼盒礼券', '礼品定制', '军刀军具', '古董文玩', '收藏品', '礼品文具', '熏香', '京东卡', '生日礼物']
            },
            cate_detail_item4: {
                cate_detail_tit: ['鲜花速递'],
                cate_detail_con: ['鲜花', '永生花', '香皂花', '卡通花束', '干花']
            },
            cate_detail_item5: {
                cate_detail_tit: ['绿植园艺'],
                cate_detail_con: ['桌面绿植', '苗木', '绿植盆栽', '多肉植物', '花卉', '种子种球', '花盆花器', '园艺土肥', '园艺工具', '园林机械']
            },
            cate_detail_item6: {
                cate_detail_tit: ['种子'],
                cate_detail_con: ['花草林木类', '蔬菜/菌类', '瓜果类', '大田作物类']
            },
            cate_detail_item7: {
                cate_detail_tit: ['农药'],
                cate_detail_con: ['杀虫剂', '杀菌剂', '除草剂', '植物生长调节剂']
            },
            cate_detail_item8: {
                cate_detail_tit: ['肥料'],
                cate_detail_con: ['氮/磷/钾肥', '复合肥', '生物菌肥', '水溶/叶面肥', '有机肥']
            },
            cate_detail_item9: {
                cate_detail_tit: ['畜牧养殖'],
                cate_detail_con: ['中兽药', '西兽药', '兽医器具', '生产/运输器具', '预混料', '浓缩料', '饲料添加剂', '全价料', '赶猪器/注射器', '养殖场专用']
            },
            cate_detail_item10: {
                cate_detail_tit: ['农机农具'],
                cate_detail_con: ['微耕机', '喷雾器', '割草机', '农机整机', '农机配件', '小型农机具', '农膜', '农技服务']
            },

        }
    }
}, {
    cate_menu_item: ['医药保健', '计生情趣'],
    right: {
        cate_channe: ['专科用药', '滋补养生', '膳食补充', '健康监测', '两性情话', '靓眼视界'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['中西药品'],
                cate_detail_con: ['感冒咳嗽', '补肾壮阳', '补气养血', '止痛镇痛', '耳鼻喉用药', '眼科用药', '口腔用药', '皮肤用药', '肠胃消化', '风湿骨外伤', '维生素/钙', '男科/泌尿', '妇科用药', '儿科用药', '心脑血管', '避孕药', '肝胆用药']
            },
            cate_detail_item2: {
                cate_detail_tit: ['营养健康'],
                cate_detail_con: ['增强免疫', '骨骼健康', '补肾强身', '肠胃养护', '调节三高', '缓解疲劳', '养肝护肝', '改善贫血', '清咽利喉', '美容养颜', '改善睡眠', '明目益智']
            },
            cate_detail_item3: {
                cate_detail_tit: ['营养成分'],
                cate_detail_con: ['维生素/矿物质', '胶原蛋白', '益生菌', '蛋白粉', '玛咖', '酵素', '膳食纤维', '叶酸', '番茄红素', '左旋肉碱']
            },
            cate_detail_item4: {
                cate_detail_tit: ['滋补养生'],
                cate_detail_con: ['阿胶', '蜂蜜/蜂产品', '枸杞', '燕窝', '膏方', '冬虫夏草', '人参/西洋参', '三七', '鹿茸', '雪蛤', '青钱柳', '石斛/枫斗', '灵芝/孢子粉', '当归', '养生茶饮', '药食同源']
            },
            cate_detail_item5: {
                cate_detail_tit: ['计生情趣'],
                cate_detail_con: ['避孕套', '排卵验孕', '润滑液', '男用延时', '飞机杯', '倒模', '仿真娃娃', '震动棒', '跳蛋', '仿真阳具', '情趣内衣']
            },
            cate_detail_item6: {
                cate_detail_tit: ['保健器械'],
                cate_detail_con: ['血压计', '血糖仪', '心电仪', '体温计', '胎心仪', '制氧机', '呼吸机', '雾化器', '助听器', '轮椅', '拐杖', '护理床', '中医保健', '养生器械', '理疗仪', '家庭护理', '智能健康', '出行常备']
            },
            cate_detail_item7: {
                cate_detail_tit: ['护理护具'],
                cate_detail_con: ['口罩', '眼罩/耳塞', '医用防疫用品', '跌打损伤', '创可贴', '暖贴', '鼻喉护理', '眼部保健', '美体护理']
            },
            cate_detail_item8: {
                cate_detail_tit: ['隐形眼镜'],
                cate_detail_con: ['彩色隐形', '透明隐形', '日抛', '月抛', '半年抛', '护理液', '润眼液', '眼镜配件']
            },
            cate_detail_item9: {
                cate_detail_tit: ['健康服务'],
                cate_detail_con: ['体检套餐', '口腔齿科', '基因检测', '孕产服务', '医疗美容']
            },
        }
    }
}, {
    cate_menu_item: ['图书', '文娱', '教育', '电子书'],
    right: {
        cate_channe: ['图书', '文娱', '教育培训', '电子书', '文娱寄卖商城'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['文学'],
                cate_detail_con: ['小说', '散文随笔', '青春文学', '传记', '动漫', '悬疑推理', '科幻', '武侠', '世界名著']
            },
            cate_detail_item2: {
                cate_detail_tit: ['童书'],
                cate_detail_con: ['0-2岁', '3-6岁', '7-10岁', '11-14岁', '儿童文学', '绘本', '科普百科', '幼儿启蒙', '智力开发', '少儿英语', '玩具书']
            },
            cate_detail_item3: {
                cate_detail_tit: ['教材教辅'],
                cate_detail_con: ['教材', '中小学教辅', '考试', '外语学习', '字典词典', '课外读物', '英语四六级', '会计类考试', '国家公务员']
            },
            cate_detail_item4: {
                cate_detail_tit: ['人文社科'],
                cate_detail_con: ['历史', '心理学', '政治军事', '传统文化', '哲学宗教', '社会科学', '法律', '文化', '党政专区']
            },
            cate_detail_item5: {
                cate_detail_tit: ['经管励志'],
                cate_detail_con: ['管理', '金融', '经济', '市场营销', '领导力', '股票', '投资', '励志与成功', '自我完善']
            },
            cate_detail_item6: {
                cate_detail_tit: ['艺术'],
                cate_detail_con: ['绘画', '摄影', '音乐', '书法', '连环画', '设计', '建筑艺术', '艺术史', '影视']
            },
            cate_detail_item7: {
                cate_detail_tit: ['科学技术'],
                cate_detail_con: ['计算机与互联网', '科普', '建筑', '工业技术', '电子通信', '医学', '科学与自然', '农林']
            },
            cate_detail_item8: {
                cate_detail_tit: ['生活'],
                cate_detail_con: ['育儿家教', '孕产胎教', '健身保健', '旅游地图', '手工DIY', '烹饪美食']
            },
            cate_detail_item9: {
                cate_detail_tit: ['刊/原版'],
                cate_detail_con: ['杂志/期刊', '英文原版书', '港台图书']
            },
            cate_detail_item10: {
                cate_detail_tit: ['文娱'],
                cate_detail_con: ['IP商品', '音乐', '游戏', '软件', '影视']
            },
            cate_detail_item11: {
                cate_detail_tit: ['教育培训'],
                cate_detail_con: ['青少年培训', '语言培训', '大学生培训', '考试考证培训', '职业技能培训']
            },
            cate_detail_item12: {
                cate_detail_tit: ['电子书'],
                cate_detail_con: ['小说', '文学', '励志与成功', '经济管理', '传记', '社会科学', '计算机与互联网', '进口原版']
            },
            cate_detail_item13: {
                cate_detail_tit: ['邮币'],
                cate_detail_con: ['纪念币', '金银币', '纸币', '古钱币', '邮票', '礼品册', '收藏工具']
            },
        }
    }
}, {
    cate_menu_item: ['机票', '酒店', '旅游', '生活'],
    right: {
        cate_channe: ['本周热推', '精选酒店', '特惠机票', '主题乐园', '电影票', '会议团建'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['交通出行'],
                cate_detail_con: ['国内机票', '国际机票', '火车票', '机场服务', '机票套餐']
            },
            cate_detail_item2: {
                cate_detail_tit: ['酒店预订'],
                cate_detail_con: ['国内酒店', '国际酒店', '酒店套餐', '超值精选']
            },
            cate_detail_item3: {
                cate_detail_tit: ['旅游度假'],
                cate_detail_con: ['国内旅游', '全球签证', '景点门票', '旅行保险']
            },
            cate_detail_item4: {
                cate_detail_tit: ['定制旅游'],
                cate_detail_con: ['团队建设', '奖励旅游', '会议周边']
            },
            cate_detail_item5: {
                cate_detail_tit: ['演出票务'],
                cate_detail_con: ['电影选座', '演唱会', '音乐会', '话剧歌剧', '体育赛事', '舞蹈芭蕾', '戏曲综艺']
            },
            cate_detail_item6: {
                cate_detail_tit: ['生活缴费'],
                cate_detail_con: ['水费', '电费', '燃气费', '城市通', '油卡充值', '加油卡']
            },
            cate_detail_item7: {
                cate_detail_tit: ['生活服务'],
                cate_detail_con: ['家政保洁', '摄影写真', '丽人/养生', '商务服务']
            },
            cate_detail_item8: {
                cate_detail_tit: ['彩票'],
                cate_detail_con: ['数据图表', '彩民服务']
            },
            cate_detail_item9: {
                cate_detail_tit: ['游戏'],
                cate_detail_con: ['QQ充值', '游戏点卡', '游戏周边', '手机游戏', '单机游戏']
            },
            cate_detail_item10: {
                cate_detail_tit: ['海外生活'],
                cate_detail_con: ['海外房产', '海外购物']
            },
        }
    }
}, {
    cate_menu_item: ['众筹', '白条', '保险'],
    right: {
        cate_channe: ['金融首页'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['众筹'],
                cate_detail_con: ['智能硬件', '流行文化', '生活美学', '公益', '其他权益众筹']
            },
            cate_detail_item2: {
                cate_detail_tit: ['东家'],
                cate_detail_con: ['阳光私募']
            },
            cate_detail_item3: {
                cate_detail_tit: ['白条'],
                cate_detail_con: ['京东白条', '白条联名卡', '京东钢镚', '安居白条']
            },
            cate_detail_item4: {
                cate_detail_tit: ['支付'],
                cate_detail_con: ['京东支付']
            },
            cate_detail_item5: {
                cate_detail_tit: ['保险'],
                cate_detail_con: ['健康险', '人寿险', '意外险', '旅行险', '财产险', '车险']
            },
            cate_detail_item6: {
                cate_detail_tit: ['企业金融'],
                cate_detail_con: ['京保贝', '京小贷', '企业主贷', '企业金采', '企业贷', '采购融资', '动产融资', '京票秒贴', '运费保理']
            },
        }
    }
}, {
    cate_menu_item: ['安装', '维修', '清洗', '二手'],
    right: {
        cate_channe: ['京东服务', '京东小家', '安装服务', '维修服务', '清洗保养', '企悦服务', '特色服务'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['家电安装'],
                cate_detail_con: ['空调安装', '电视安装', '洗衣机安装', '热水器安装', '烟机/灶具安装', '净水器安装']
            },
            cate_detail_item2: {
                cate_detail_tit: ['办公安装'],
                cate_detail_con: ['电脑安装', '办公设备安装']
            },
            cate_detail_item3: {
                cate_detail_tit: ['家居安装'],
                cate_detail_con: ['家具安装', '灯具安装', '智能家居安装', '五金卫浴安装', '晾衣架安装']
            },
            cate_detail_item4: {
                cate_detail_tit: ['家电维修'],
                cate_detail_con: ['空调维修', '电视维修', '洗衣机维修', '冰箱维修', '热水器维修', '油烟机维修', '燃气灶维修']
            },
            cate_detail_item5: {
                cate_detail_tit: ['手机维修'],
                cate_detail_con: ['屏幕换新', '电池换新', '手机故障', '保障服务']
            },
            cate_detail_item6: {
                cate_detail_tit: ['办公维修'],
                cate_detail_con: ['笔记本维修', '平板维修']
            },
            cate_detail_item7: {
                cate_detail_tit: ['清洗保养'],
                cate_detail_con: ['家电清洗', '家居家纺洗护', '服装洗护', '鞋靴箱包保养']
            },
            cate_detail_item8: {
                cate_detail_tit: ['特色服务'],
                cate_detail_con: ['家庭优惠套装', '企悦服务', '体育服务', '骑行服务', '钟表维修/保养']
            },
            cate_detail_item9: {
                cate_detail_tit: ['二手数码'],
                cate_detail_con: ['苹果手机', '安卓手机', '充电器', '手机壳', '耳机/耳麦', '单反相机', '微单相机', '镜头', '智能手表', '游戏机']
            },
            cate_detail_item10: {
                cate_detail_tit: ['二手电脑'],
                cate_detail_con: ['笔记本', '官翻电脑', '平板电脑', '台式机', '一体机', '显示器', '显卡', 'CPU', '主板', '机箱', '组装电脑']
            },
            cate_detail_item11: {
                cate_detail_tit: ['二手奢品'],
                cate_detail_con: ['钟表', '箱包', '饰品', '配件', '腰带', '钱包', '服饰', '鞋靴']
            },
            cate_detail_item12: {
                cate_detail_tit: ['二手书'],
                cate_detail_con: ['期刊杂志', '教材', '文化社科', '历史', '经管', '文学', '小说', '艺术', '生活', '童书']
            },
        }
    }
}, {
    cate_menu_item: ['工业品'],
    right: {
        cate_channe: ['元器件', '企业专享', 'PLUS会员', '工品优选', '企业购'],
        cate_detail: {
            cate_detail_item1: {
                cate_detail_tit: ['工具'],
                cate_detail_con: ['手动工具', '电动工具', '测量工具', '气动工具', '工具套装', '工具配件']
            },
            cate_detail_item2: {
                cate_detail_tit: ['劳动防护'],
                cate_detail_con: ['手部防护', '足部防护', '身体防护', '头部防护', '眼脸部防护', '呼吸防护', '坠落防护', '静电无尘']
            },
            cate_detail_item3: {
                cate_detail_tit: ['安全消防'],
                cate_detail_con: ['警示标识', '应急处理', '监控设备', '安全锁具', '化学品存储', '消防器材', '消防服装']
            },
            cate_detail_item4: {
                cate_detail_tit: ['工控配电'],
                cate_detail_con: ['开关电源/UPS', '工业通讯设备', '控制柜箱', '断路器', '接触器', '继电器', '变频器', '电料辅件']
            },
            cate_detail_item5: {
                cate_detail_tit: ['仪器仪表'],
                cate_detail_con: ['温度仪表', '电工仪表', '气体检测', '分析检测', '压力仪表', '流量仪表', '物位仪表', '阻容感及晶振', '半导体', '模块及开发板']
            },
            cate_detail_item6: {
                cate_detail_tit: ['清洁用品'],
                cate_detail_con: ['清洁工具', '清洁设备', '清洗保养品', '工业擦拭', '地垫', '垃圾处理', '清洗剂']
            },
            cate_detail_item7: {
                cate_detail_tit: ['化学品'],
                cate_detail_con: ['润滑剂', '胶粘剂', '化学试剂', '工业涂层', '清洗剂', '防锈剂', '脱模剂']
            },
            cate_detail_item8: {
                cate_detail_tit: ['仓储包装'],
                cate_detail_con: ['包装工具', '包装耗材', '标签耗材', '搬运设备', '存储设备', '起重设备']
            },
            cate_detail_item9: {
                cate_detail_tit: ['焊接紧固'],
                cate_detail_con: ['五金紧固件', '密封件', '焊接设备', '焊接耗材']
            },
            cate_detail_item10: {
                cate_detail_tit: ['机械配件'],
                cate_detail_con: ['轴承', '皮带链条', '机械零配件', '机床及附件', '刀具', '气动元件', '泵阀类']
            },
            cate_detail_item11: {
                cate_detail_tit: ['暖通照明'],
                cate_detail_con: ['暖通', '工业照明', '管材管件']
            },
            cate_detail_item12: {
                cate_detail_tit: ['实验用品'],
                cate_detail_con: ['实验室试剂', '实验室耗材', '实验室设备']
            },

        }
    }
}];
// 轮播图右边的最下边的小图标
let bodyrListImg = {
    //   原来的图标
    'beforIcon': [
        'https://m.360buyimg.com/babel/jfs/t1/57014/6/10297/815/5d773a07Ec7a61fc9/97917a2daa34be0f.png',
        'https://m.360buyimg.com/babel/jfs/t1/40738/20/14562/826/5d773a01E09eb8121/d6f3909618c6307a.png',
        'https://m.360buyimg.com/babel/jfs/t1/64347/37/9953/720/5d7739a6Ef5f451d6/4e2bc2d96b0fbbec.png',
        'https://m.360buyimg.com/babel/jfs/t1/71890/14/9897/3048/5d7739ddE93eb94f8/f1f6dc5c207329f9.png',
        'https://m.360buyimg.com/babel/jfs/t1/50019/25/10190/3699/5d7739d7Ed503c6cc/6aa3afbe6c3a0951.png',
        'https://m.360buyimg.com/babel/jfs/t1/49654/24/10325/2901/5d7739caE0db5e87b/d9d908ad415a5265.png',
        'https://m.360buyimg.com/babel/jfs/t1/56296/3/10260/1443/5d7739f3E233abc53/e6976f3cb30c9a8a.png',
        'https://m.360buyimg.com/babel/jfs/t1/51584/31/10221/1685/5d7739e7E1adb25cd/1d0957d7f2ae01a2.png',
        'https://m.360buyimg.com/babel/jfs/t1/9966/19/18575/2703/62fb7416E91849618/14a4b81a50f2a535.png',
        'https://m.360buyimg.com/babel/jfs/t1/45761/32/10307/1581/5d7739e2Ece4b6671/0004c1b85fbf7bde.png',
        'https://m.360buyimg.com/babel/jfs/t1/52668/12/10399/979/5d7739d1Efd1b6a04/18668c963bf9d646.png',
        'https://m.360buyimg.com/babel/jfs/t1/60778/37/9838/3066/5d7739faEd3b7dbb9/dd4d9ef7ce8fc169.png'],
    // 悬浮变色的图标
    'afterIocn': [
        "https://m.360buyimg.com/babel/jfs/t1/55911/31/402/858/5cd4f23eE6f536460/5da079255c6dfabe.png",
        "https://m.360buyimg.com/babel/jfs/t1/45316/3/388/884/5cd4f25eEea4c67ed/671f7c186c5e9b01.png",
        "https://m.360buyimg.com/babel/jfs/t1/45423/33/385/778/5cd4f265E442a9342/0aff0a42cece09ee.png",
        "https://m.360buyimg.com/babel/jfs/t1/36002/35/9106/3311/5cd4f1bdE06ff07ed/9570fdd46ecd3a76.png",
        "https://m.360buyimg.com/babel/jfs/t1/57520/8/375/4092/5cd4f1d8Ea1266047/1c590322ece537ba.png",
        "https://m.360buyimg.com/babel/jfs/t1/34261/15/10242/3120/5cd4f256E10257aba/8f3f63ae04ff19af.png",
        "https://m.360buyimg.com/babel/jfs/t1/39983/24/6834/1596/5cd4f247E8cf89f1e/b8a8418d5418f471.png",
        "https://m.360buyimg.com/babel/jfs/t1/50929/1/374/1847/5cd4f1eaE5daf90db/cebbff76b25dc22e.png",
        "https://img12.360buyimg.com/imagetools/jfs/t1/164234/18/29348/2711/62fb6f56E9e45a090/454c7d913a51126b.png",
        "https://m.360buyimg.com/babel/jfs/t1/58891/36/278/1745/5cd4f1e0Ef4cc50a7/f12276b17e5dcf3b.png",
        "https://m.360buyimg.com/babel/jfs/t1/44601/19/915/1039/5cd4f1cfE2e46473c/b61f083872a7a1de.png",
        "https://m.360buyimg.com/babel/jfs/t1/41106/15/4551/3300/5cd4f1c7E507148c7/90a218f053e903d2.png"
    ],
    // 图标的标题
    'iconTitle': ['礼品卡', '企业购', '话费', '加油卡', '游戏', '机票', '白条', '众筹', '五金城', '火车票', '电影票', '酒店']
};
// 秒杀旁边的手动轮播图
const msLb = [
    {
        img: 'https://img12.360buyimg.com/seckillcms/s140x140_jfs/t1/84938/19/18202/19902/639696baE6e290ca7/53aa7c4a7d44bf21.jpg.webp',
        jie: '鑫一帆章丘铁锅 炒锅无涂层不易粘烹饪锅家用圆底燃气炉炒菜锅 32厘米',
        jia: '¥1380.00'
    },
    {
        img: 'https://img14.360buyimg.com/seckillcms/s140x140_jfs/t1/89250/9/35390/36646/64097bdfFc7d1b49e/e5d94a988857d770.jpg.webp',
        jie: '露安适（Lelch）日夜安护学走裤L码32片(9-14kg) 薄护适动 大号婴儿拉拉裤',
        jia: '¥87.00'
    },
    {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/41299/34/18906/10420/631ab04fEd953c629/a8e724fe873263ad.jpg.webp',
        jie: 'JBL WAVE FLEX 真无线蓝牙耳机 半入耳式音乐耳机 通话降噪运动防汗苹果安卓手机带麦游戏耳机 珍珠白',
        jia: '¥359.00'
    },
    {
        img: 'https://img13.360buyimg.com/seckillcms/s140x140_jfs/t1/104304/15/37692/27598/640595a4Fc84ef5a8/55f3435e012aae2f.jpg.webp',
        jie: '华硕a豆14 a豆14 Pro 12代酷睿标压高色域屏高性能轻薄笔记本电脑商务办公学生手提 a豆14钛空银 R5-5500U IPS防眩光屏 配置一 16G内存 512G固态',
        jia: '¥3569.00'
    },
    {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/155703/22/35655/57123/63fef24aF171c95c4/e7f04f1ab27e0e6f.jpg.webp',
        jie: '欧臻廷保湿修护亮颜银霜面霜70ml护肤品化妆品乳液滋润送女友礼物礼盒款',
        jia: '¥1380.00'
    },
    {
        img: 'https://img30.360buyimg.com/seckillcms/s140x140_jfs/t1/107510/22/22861/98537/628ca5caE4a4fa7e4/d29d2f7bea40b3bb.jpg.webp',
        jie: 'Redmi K50Pro 天玑9000 AMOLED 2K柔性直屏 OIS光学防抖 120W快充 幻镜 8GB+256GB 5G智能手机 小米红米',
        jia: '¥2619.00'
    },
    {
        img: 'https://img11.360buyimg.com/seckillcms/s140x140_jfs/t1/109242/28/23835/49558/622afda5E603886a6/218e712f7c69864d.jpg.webp',
        jie: '卡诗（KERASTASE）黑钻钥源鱼子酱洗发水250ml 改善毛躁呵护受损',
        jia: '¥219.00'
    },
    {
        img: 'https://img30.360buyimg.com/seckillcms/s140x140_jfs/t1/143721/14/29663/14312/6323e7baE170e5930/e3c81609494ff97a.jpg.webp',
        jie: '森海塞尔（Sennheiser）MOMENTUM真无线3代 蓝牙自适应动态降噪运动耳机 入耳式音乐耳机 黑色',
        jia: '¥1549.00'
    },
    {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/81699/36/18618/88877/628b2467E11be1543/ac724d1dcd55c165.jpg.webp',
        jie: 'Redmi K50Pro 天玑9000 AMOLED 2K柔性直屏 OIS光学防抖 120W快充 银迹 8GB+256GB 5G智能手机 小米红米',
        jia: '¥2619.00'
    },
    {
        img: 'https://img12.360buyimg.com/seckillcms/s140x140_jfs/t1/200564/31/30737/36995/6409b3a3Fd40e37b3/6748be3e32f1022b.jpg.webp',
        jie: '华为nova9se 新品上市手机 【现货速发】冰晶蓝 8GB+128GB 官方标配',
        jia: '¥1469.00'
    },
    {
        img: 'https://img30.360buyimg.com/seckillcms/s140x140_jfs/t1/220590/24/22310/35669/6400688bFa2fca68f/58a951aff976b276.jpg.webp',
        jie: '日本无痕文胸运动内衣女聚拢无钢圈薄款文胸背心胸罩美背【多款可选】 背心款:肤色(单件装) L(建议120-130斤 80CD & 85AB)',
        jia: '¥29.00'
    },
    {
        img: 'https://img10.360buyimg.com/seckillcms/s140x140_jfs/t1/196933/36/30223/41300/6389ac0bE6dbbb1e1/24db5a7bf9475b39.jpg.webp',
        jie: '百事可乐细长罐330ml*24罐 混合装 上海百事可乐公司出品(百事16美橙4七4)',
        jia: '¥39.89'
    }, {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/127514/23/35384/70081/640713e5Fb757be47/8605e05a320df39c.jpg.webp',
        jie: '惠丰优牧 希酪牛奶250ml*10盒/箱 蛋白质含量4.0g钙含量140mg牛奶整箱',
        jia: '¥31.90'
    },
    {
        img: 'https://img14.360buyimg.com/seckillcms/s140x140_jfs/t1/172127/22/34163/137793/6405539eF7aac5051/1f8363a67f75763a.jpg.webp',
        jie: '罗蒙斜纹长袖衬衫男新款中青年男士商务休闲棉质职业工装衬衣 C21白色【有口袋】',
        jia: '¥69.00'
    },
    {
        img: 'https://img14.360buyimg.com/seckillcms/s140x140_jfs/t1/137685/40/34063/160182/6405961eF97784374/9edeb892714146d8.png.webp',
        jie: '佐丹奴男休闲裤男装弹力卡其裤子男青少年长裤01110583 09经典黑色-常规版',
        jia: '¥109.90'
    },
    {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/102233/38/25035/75585/64094b4cF328d8828/2395b5c94abf86f3.jpg.webp',
        jie: 'M汽车贴膜朗清系列 深色轿车全车汽车玻璃车膜太阳膜隔热膜 包施工',
        jia: '¥1499.00'
    },
    {
        img: 'https://img12.360buyimg.com/seckillcms/s140x140_jfs/t1/138879/26/34306/49881/640003efF29fb876d/d0eac3c58ccdb97d.jpg.webp',
        jie: '河套酒业 河套王淡雅 浓香型白酒 52度 商务聚会送礼 500ml单瓶礼盒装',
        jia: '¥508.00'
    },
    {
        img: 'https://img12.360buyimg.com/seckillcms/s140x140_jfs/t1/179232/32/32936/38418/64080905F6ca3ae62/421b4b8f3a4ca3e0.jpg.webp',
        jie: '漫步者（EDIFIER）HECATE G4Spro 2.4G蓝牙无线7.1游戏耳机头戴式 双模多平台兼容电脑电竞吃鸡耳机耳麦 黑色',
        jia: '¥349.00'
    },
    {
        img: 'https://img20.360buyimg.com/seckillcms/s140x140_jfs/t1/178193/3/33428/43824/64093fd0F92b01eee/96f660acea49c641.jpg.webp',
        jie: '吉普 JEEP 夹克男棉衣男情侣款夹克秋冬三合一加厚两件套防风防水保暖外套棉服 552/冲锋衣男白色 4XL',
        jia: '¥259.00'
    },
    {
        img: 'https://img30.360buyimg.com/seckillcms/s140x140_jfs/t1/220722/9/21877/80908/6409c9feF94ce723f/6e595af164a71381.jpg.webp',
        jie: '百事可乐 Pepsi 碳酸饮料整箱 300ml*12瓶 (新老包装随机发货) 百事出品',
        jia: '¥17.89'
    },

]
// 频道广场
let channeData = [
    {
        tit: '防疫指南',
        src: [
            "https://img13.360buyimg.com/babel/s580x740_jfs/t1/182640/15/31369/21199/639811efE58657440/a95cf1d2e3252145.png!cc_290x370.webp"
        ]
    }, {
        tit: '京东拍卖',
        src: [
            "https://img14.360buyimg.com/babel/s580x740_jfs/t1/131098/35/32947/61967/6412d528Fe711ca1f/59d1f9a282bb6c8c.png!cc_290x370.webp"
        ]
    }, {
        tit: ['企业好店', '企业用户都在逛'],
        src: [
            "https://img30.360buyimg.com/img/s200x200_jfs/t1/144746/35/33664/48546/6412ea6cFb3f0aab0/797de986ced063ce.jpg!cc_100x100.webp",
            "https://img20.360buyimg.com/img/s200x200_jfs/t1/106800/9/37293/33468/6414393cF6faac01f/742378431a00d556.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['生鲜馆', '尝遍天下鲜'],
        src: [
            "https://img13.360buyimg.com/img/s200x200_jfs/t1/62924/21/24639/121619/641523a8F6ba16732/3c6611fad4abcac4.jpg!cc_100x100.webp",
            "https://img11.360buyimg.com/img/s200x200_jfs/t1/102602/24/31357/117202/6412d5ccF71b23e83/5706eae5e21ffdd3.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['京东图书', '专注优质好书'],
        src: [
            "https://img12.360buyimg.com/img/s200x200_jfs/t1/75588/31/23523/74161/636e7554E9dad8e40/e03569664670d0de.jpg!cc_100x100.webp",
            "https://img13.360buyimg.com/img/s200x200_jfs/t1/217695/32/23567/156149/637df0e2Edeae3c79/875d6bd01b3bbb20.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['冰箱洗衣机', '品质生活必备'],
        src: [
            "https://img11.360buyimg.com/img/s200x200_jfs/t1/175625/11/29667/32198/640fc869F0292860f/ab83106cf244883b.jpg!cc_100x100.webp",
            "https://img20.360buyimg.com/img/s200x200_jfs/t1/181552/2/33916/113423/64142664F2e52a3d8/138efaf224132e7b.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['企业购', '一站式企业采购平台'],
        src: [
            "https://img20.360buyimg.com/img/s200x200_jfs/t1/69809/27/11148/219741/5d84ad41E11d96c77/ca245d3be572b4bc.jpg!cc_100x100.webp",
            "https://img10.360buyimg.com/img/s200x200_jfs/t1/202368/6/19128/89165/61c043d5E2455d86e/3f95940946ee7472.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['京东超市', '一站式囤生活好物'],
        src: [
            "https://img12.360buyimg.com/img/s200x200_jfs/t1/187406/36/28187/140234/63203446E34cba3cb/0223cf8007ad928f.jpg!cc_100x100.webp",
            "https://img12.360buyimg.com/img/s200x200_jfs/t1/34853/15/4254/232401/5cbb0c19Ec38ed21d/3afd83b755246887.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['拍拍二手', '大牌1元抢'],
        src: [
            "https://img12.360buyimg.com/img/s200x200_jfs/t1/191660/36/28838/59253/631d3b20E9389bee8/ca3f8cbae20783e2.jpg!cc_100x100.webp",
            "https://img11.360buyimg.com/img/s200x200_jfs/t1/200595/8/32490/71173/641178baF2083d524/f36807effd3c52fa.jpg!cc_100x100.webp"
        ]
    }, {
        tit: ['京东京造', '京东自有品牌'],
        src: [
            "https://img14.360buyimg.com/img/s200x200_jfs/t1/207789/9/29472/114811/63d8b005F3c984e35/033e0a53bfd264a9.jpg!cc_100x100.webp",
            "https://img11.360buyimg.com/img/s200x200_jfs/t1/113678/19/33602/43756/64057e75F5b42ccd1/3c659439deb11a34.jpg!cc_100x100.webp"
        ]
    }
]
// 为你推荐的title
let pushSellTitData = [
    ["精选", "猜你喜欢"],
    ['智能先锋', '大电器城'],
    ['居家优品', '品质生活'],
    ['超市百货', '百货生鲜'],
    ['时尚达人', '美妆穿搭'],
    ['进口好物', '京东国际']
]
// 为你推荐
let pushSellData = {
    // 精选
    '精选': {
        imgs: [
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/190987/5/32488/105569/640ef0c2F01176c52/df2998a3727a599f.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/16309/12/18492/289626/62dfbfe3E21879b66/22b36c44a529544a.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/54492/12/23739/50517/640ac8ceFc5236d2f/51f7d6094b4f00d7.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/45893/25/22155/111689/640599dcF4f23d99c/6b9e4bce08e71f03.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/193643/5/32655/93167/640727daFa62cf88e/2a7c962a9fc299fe.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/148825/13/34599/126704/64059b52F0d338908/893ff8cfe6217450.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/88631/38/21927/61480/640ac92eF50375c5a/e277a71fac59ad4b.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/179474/32/32410/128701/640599e3Fa8231967/1fe057967185830e.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/94002/36/33538/102708/63fc4a1bF4500f063/5c0b44c5736a3b83.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/106710/27/21503/117514/64059983Fb58746a3/b45149ca5438df86.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/113034/11/30325/102515/63ff2174Fc887626a/7960e3c8bb865531.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/142290/17/35067/64168/64059c2bFd9ba19c8/0c12c757c77379eb.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/197992/8/30903/109805/640f3c64F80a723cb/2c018495bcd1f0c7.png",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/185010/28/34189/98458/640ef2bcF8dabe4fb/0fbd608574bb93d5.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/86418/15/28581/467935/628f5f39E4d74b9a8/4f41f6b472fdf52b.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/130571/31/36069/131076/64059bbeFf69cf19a/91a9652638c023fd.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/86380/25/34294/135347/64101971F26be714c/6c70ec56ef863026.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/61379/29/25228/61696/64059b65F5fcfde92/da6b92c0f2aee0c4.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/203544/39/27610/107592/64059dfdF7a7e790b/3b788cd72c253665.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/91423/5/34045/64581/64059a90F63d393ea/0579bd7a3b0906a9.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/217719/5/25923/75036/640ef4a3Fca0f8374/c8ebc1da75677326.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/192086/1/33352/155667/64059cb7Ff1fd9a1c/e9a78014700258f1.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/74767/38/25603/152931/6405b6edF85096d99/40472b794936d997.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/205862/29/29242/6759/636e089dE33460160/af70e930c67b79d3.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/119430/18/33036/173908/64093c74Fa2b2e524/392d83858bb8cd52.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/127751/15/31277/99064/63310ca9E3475c548/3a016a11286386cb.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/189161/36/32982/70612/640895b5Fe85110ec/d0379776038ec774.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/78050/11/19412/141027/64059c26F618ba4a2/04200bb0c208b53f.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/31529/9/21453/134574/640e6db0F68f54324/91099a2824435b17.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/127210/22/34867/116216/6405f803Fe7fa9ee0/b6a876a0d5427930.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/204658/17/31259/95640/63fef808Fe358f011/e3a90bf2b8cd59ca.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/156967/37/35186/90365/6405b41cF8bbcd28c/008f3cd557eca699.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/126989/34/30381/84280/63e33532Fa1e50d31/a411aaa48a6e9b82.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/218418/22/11821/268814/61ff884cE18d96dee/9815ff4cc5f166c2.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/139961/15/33931/65646/640aa41dF3f0c5f4c/fc43c64721164828.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/133429/1/35469/48808/64060b24F30ae5627/9498fc15221bbc06.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/123832/29/35886/119652/640efc90Fd8bb7bcf/c125e45202a0aacf.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/65933/10/20650/258125/62d8ec24Ef9490a2b/31346c2b0877aea5.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/139239/4/20265/131247/5fe69cdbEf57e880d/30e315393b9fdf84.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/104103/40/37371/166474/63eafaa1Fe33621f2/cf67c84c27934e9c.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/169775/5/32857/71614/6382e6daE7ceefcce/475a1c5915e53a0b.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/169782/35/29790/67550/6309997bE7df60956/c8028b5a76d46bd7.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/107103/3/34703/105047/63a2c844E7e8668bf/ef61ea07ebd81b90.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/115349/14/30063/79334/637338a0E7791d312/3fc8e65d6d3b11a0.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/105254/32/37586/75224/6406096dF49f812ff/3112eefeb80f09a9.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/94679/16/13671/84264/5e5c9317Efd1954f6/17cc8e811774ab9a.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/106828/33/29754/408956/63b778edF44cab2b2/4c725ee3b514b032.jpg",
            "https://img30.360buyimg.com/jdcms/s150x150_jfs/t1/130053/24/29760/82337/640eee90F31b2c2d9/1002eb4185394f9a.jpg",
            "https://img11.360buyimg.com/jdcms/s150x150_jfs/t1/191251/19/31004/40191/63707e72E922fe2c9/386a7a3bcf2024d8.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/110750/36/35910/352790/64102b6fF977b1841/706f6b3756a832a3.png",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/140364/15/23671/119017/6242c254Eb4f1b779/12d14982ea017cb9.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/181892/23/34499/68182/640d7cadF677dae07/759a8ced934dd75b.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/5550/16/18515/65180/64059978Ff4b75875/03c6ab6df1c1296d.jpg",
            "https://img14.360buyimg.com/jdcms/s150x150_jfs/t1/185368/3/33727/97990/640f4befF8daeebec/a6554d02f72c9c22.jpg",
            "https://img20.360buyimg.com/jdcms/s150x150_jfs/t1/186439/8/33665/162359/6405b405Fbb1d61e1/85d1882038a2e2f7.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/182549/8/13516/176924/60e95d00E5d6d1618/cae2f0249c7b7692.jpg",
            "https://img10.360buyimg.com/jdcms/s150x150_jfs/t1/210725/10/30381/97667/640ebc40Fa98bcd83/e88393161b7f924e.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/209510/40/26255/74395/63575dd8Ee09695c5/34c6d70b444634eb.jpg",
            "https://img12.360buyimg.com/jdcms/s150x150_jfs/t1/50713/24/23488/76493/63f5738aF7d73ef0a/29981a15060191bc.jpg",
            "https://img13.360buyimg.com/jdcms/s150x150_jfs/t1/35837/21/17265/67222/630495c4E4fcd2e3f/1d9f2e14933ff3f7.jpg"
        ],
        titles: [
            "自营华硕（ASUS）天选4 锐龙版 15.6英寸高性能电竞游戏本 笔记本电脑(新R7-7735H 16G 512G RTX4060 144Hz高色域电竞屏)青",
            "自营ROG枪神6 第12代英特尔酷睿i7 15.6英寸电竞游戏本笔记本电脑(i7-12700H 液金导热 16G 512GB 2.5K RTX3060)",
            "自营ROG枪神7 Plus 第13代酷睿i9 18英寸电竞游戏本笔记本电脑(i9-13980HX 液金导热 16G 1T RTX4070 240Hz)",
            "森必居茶几 网红岩板茶几桌客厅家用北欧轻奢现代方形组合玻 岩板黑架70古堡灰50鱼",
            "ROG幻16 翻转 2023 第13代英特尔酷睿i9 16英寸 星云原画屏 翻转触控高性能轻薄笔记本电脑 i9-13900H RTX4060 16G 1TB SSD 2.5K 240Hz",
            "派森柏 办公室沙发简约现代商务会议会客接待室休闲休息区三 深灰色+米白 单人70CM",
            "自营ROG幻16 经典版 第13代酷睿i9 16英寸星云屏设计师游戏本笔记本电脑(i9-13900H 16G 1T RTX4070 2.5K)经典黑",
            "森必居书桌书架一体桌家用学生学习桌简约现代带抽屉卧室电 田园橡木色100*50*147",
            "ROG枪神7 Plus 第13代英特尔酷睿i9 18英寸 星云屏 电竞游戏本笔记本电脑 RTX4070 16G 1TB SSD i9-13980HX 2.5K 240Hz 广色域",
            "森必居 餐边柜多层储物柜家用厨房碗柜置物柜餐厅收纳柜边 【三门一抽】天空灰+浅",
            "自营小米笔记本电脑 红米 Redmi Book Pro15 3.2K高色域屏 商务办公 高清屏轻薄本(R7-6800H 16G 512G 带摄像头)",
            "森必居定制防渗漏托盘防渗漏塑料托盘定制聚丙烯塑料耐酸碱 PP托盘50*35*5cm",
            "华硕天选4 15.6英寸高性能游戏本笔记本电脑 13代i9/RTX4060/1TB/2.5K灰 16G/高刷高色域电竞屏",
            "自营九阳（Joyoung）无涂层精铁炒锅铁锅32cm炒菜锅不易锈电磁炉燃气煤气通用烹饪锅具",
            "自营玩家国度ROG 耀光2 机械键盘 有线游戏键盘 RGB背光 8k回报率 104键 PBT键帽 带掌托 黑色NX山楂红轴",
            "派森柏 书桌书架一体桌台式办公桌女生卧室电脑桌简易家用学 100cm暖白",
            "联想拯救者Y9000P 2022电竞游戏笔记本电脑 满血版RTX3060独显 12代酷睿十四核 i9-12900H 16G 512G固态 标配版 16英寸 2.5K超高清｜165Hz专业电竞屏",
            "森必居沙发床 小孩沙发床沙发折叠床沙发可爱卡通懒人折叠单 灰色 哈士奇-三层折叠",
            "森必居屏风 隔断柜进门玄关柜客厅简约入户正对门装饰现代新 置物款190*70*30",
            "森必居 轻奢吊柜墙壁柜顶柜厨房卧室卫生间收纳柜壁挂式阳台 红色 组装",
            "自营九牧（JOMOO）不锈钢上水头编织软管花洒耐热防爆淋浴软管1.5米H2BE2-150103C-2",
            "森必居单人沙发椅网红轻奢现代简约北欧卧室阳台休闲极简单 豆沙粉(磨砂黑脚)",
            "雷神911X猎荒者2023款13代酷睿满血独显直连电竞学生游戏本15.6英寸轻薄设计笔记本电脑 i5-13500H/RTX4060/165Hz 16G内存+512G固态 |官方标配",
            "HKNLusb净化车载加湿器定炫彩杯加湿器大雾量迷你家用卧室空调房桌面 220彩蛋粉色 套餐2【+5滤芯】",
            "鹿为 自定义键盘机械小键盘游戏绘图可宏编程特制迷你复制粘贴快捷键 自定义9键黑色-配USB AtoC线",
            "派森柏（PAISENBO）干花团扇 中国风diy材料包儿童手工制作永生花古风扇子母亲节礼物 暗香",
            "ROG 枪神X 第13代英特尔酷睿i9（可超频）水冷旗舰电竞游戏主机台式机电脑 星空黑 i9-13900KF 32G 1TSSD+1THDD RTX3090 24G",
            "派森柏 沙发床可折叠两用沙发客厅多功能储物沙发床乳胶沙发 灰 1米裸床无床板30张起",
            "LG 28MQ780 2K显示器 16:18魔方屏 Nano IPS面板 硬件校准 内置KVM Type-C充电90W 设计师 代码 Ergo二代支架 PBP功能 液晶显示屏幕",
            "哥窑功夫茶具套装家用办公会客轻奢中式整套陶瓷茶杯泡茶神器 茶壶秘釉哥窑10件",
            "联想 27英寸 4K显示器 IPS 10.7亿色 10bit 四边微边 爱眼低蓝光 商用办公图像视频 电脑显示屏 H2721U",
            "揽欧移动茶桌家用小茶台实木茶车茶几茶具套装全自动烧水壶一体茶 升级胡桃色泡茶柜 组装",
            "自营ROG魔霸新锐 15.6英寸2.5K 165Hz游戏本笔记本电脑(R9-6900HX 液金导热 16G 512G RTX3060 140W)",
            "美科耀 【可定制】窗帘遮阳遮光窗帘隔热防晒阳台办公室窗帘卷帘定制 双面同色烟灰全遮光",
            "自营LG 27英寸 4K 144Hz (超频160Hz) HDMI2.1 NanoIPS HDR600 10.7亿色 PS5 电竞显示器 27GP95R",
            "适用于长安cs75plus汽车钥匙套逸动cs55悦翔cs15欧尚unit钥匙包扣 A款 改装后配版 黑色",
            "自营ROG棱镜 游戏耳机 头戴式耳机 环绕7.1音效 有线无延迟 USB/TypeC Switch耳机 可拆卸麦克风 ROG手机耳机",
            "西萤 PVC折叠门厨房开通燃气临时门 免打孔简易门卫生间隔断伸缩门阳台推拉折叠门厕所浴室隐形移门 定制尺寸联系客服",
            "自营TaTanice 创意3D立体便签纸 生日礼物高档便利贴纸雕可撕便签本送女友老婆",
            "迪普艾斯 磁铁自吸软门帘家用空调隔断门帘pvc透明门帘塑料磁性挡风防冷气门帘超市商场商用隔热门帘 灰色2.0mm厚加配重 尺寸定制/联系客服",
            "礼品塑料椅子简约靠背凳子北欧餐椅家用大人经济型塑胶椅加厚牛角椅子 深灰色- 深蓝色-加厚款 加厚款",
            "喝茶水杯 茶杯随身水杯男女学生水瓶便携滤网随手杯太空杯茶杯防摔带刻度塑料杯 杯子 TY-2019颜色随机480ml",
            "双帝（SHUANGDI）庭院花园别墅新中式凉亭铝合金户外亭子四角凉亭 定制尺寸和款式",
            "自营百字管道壁挂遮挡免打孔洞洞板置物架天然气管道遮丑 定制款",
            "手机车载支架2021中控仪表台后视镜多功能创意汽车AR导航固定 新三代升级1620度自带停",
            "罗技（Logitech） Craft 无线蓝牙键盘 办公键盘 超薄 带优联 深灰色 旗舰款 【Craft】无线蓝牙/超薄/带旋钮",
            "自营潜水艇（Submarine）SQ-1 面盆洗手池防臭下水管 S弯伸缩下水管 防虫防臭",
            "机械师星辰15 144Hz游戏本14核酷睿i7-12700H RTX3050Ti独显笔记本电脑 加强版16G/512G PCIE高速固态",
            "HKNL全金属三号汽车香水空调出风口带轮轴车内空气净化器车载 金色【带灯单个装】-2片香薰d 芬芳【桂花味】",
            "华为（HUAWEI） 笔记本电脑MateBook D14 轻薄便携商务办公学生超薄本 D14灰｜R5-5500U 16G+512G集显",
            "【谨防刷单诈骗】曹操出行20元充值卡网约车打车抵扣券20元现金卡优惠卡券 官方卡密兑换码",
            "联想笔记本电脑V15 15.6英寸办公商务游戏设计本学生网课手提本 Intel N4020/4G/256G固态硬盘 全高清防眩光屏 精装升级",
            "森必居欧式文件柜矮柜办公柜打印机柜办公室柜储物柜茶水柜 浅白单门木脚 80*40*7 0.0mm",
            "ROG 玩家国度 狂战士GK2000有线电竞游戏机械键盘 RGB背光樱桃红轴105键带掌托 黑色",
            "揽欧移动茶桌茶台家用阳台实木小茶车茶几功夫茶具盘套装烧水壶一 【胡桃木色】单门带抽款长64-无 组装",
            "南极人（home） 乳胶床垫加厚学生宿舍单人0.9m1.2米上下铺针织海棉垫可折叠榻榻米加厚床垫床褥 立体花瓣白约6cm厚 90*190cm",
            "自营雷士（NVC） LED筒灯天花灯 金属铝材砂银 4瓦暖白光4000K 开孔70-80mm【绿色家居】",
            "美斯尼 茶壶玻璃泡茶壶 加厚耐热玻璃泡茶器创意墨色玻璃功夫茶具 墨色壶 560mL",
            "标弹汽车补漆笔车漆划痕修复神器珍珠白黑银灰色深度修补蜡膏油自喷漆 单支补漆笔 通用白",
            "天语i13智能小屏幕手机迷你水滴全面屏4G全网通128G大内存学生游戏超薄超小双卡双待 远峰蓝 8+128G"
        ],
        prices: [
            "7499.00",
            "10969.00",
            "15999.00",
            "322.42",
            "13499.00",
            "323.40",
            "15499.00",
            "282.24",
            "14999.00",
            "184.24",
            "4578.00",
            "123.61",
            "9999.00",
            "58.00",
            "999.00",
            "135.14",
            "9088.00",
            "300.00",
            "311.64",
            "204.82",
            "21.00",
            "390.04",
            "7799.00",
            "26.00",
            "129.00",
            "122.55",
            "19.80",
            "22999.00",
            "341.82",
            "4599.00",
            "89.00",
            "1249.00",
            "206.78",
            "9299.00",
            "25.00",
            "23.00",
            "4699.00",
            "119.00",
            "749.00",
            "10.00",
            "148.00",
            "10.00",
            "43.12",
            "11.00",
            "50.00",
            "10.00",
            "129.00",
            "819.00",
            "35.00",
            "5989.00",
            "16.00",
            "4099.00",
            "20.00",
            "2098.00",
            "391.02",
            "1099.00",
            "255.78",
            "98.00",
            "15.90",
            "69.00"
        ]
    },
    '智能先锋': {
        // 智能先锋
        imgs: [
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/156174/25/19049/30705/60642bafEdbd4f3c5/268a7d1d487797c7.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/106437/39/24148/163871/62159e1dE5bebb77a/058c8d39e225a167.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/194182/1/22862/67957/625d2469E22090d30/1f57e5ce9056e35f.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/136571/14/7445/66621/5f3ca74eE50d5fc8b/6422aa2178453180.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/196704/3/26659/37853/62f0a9f8Ecd6bd5ff/d50db104e01f804b.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/165781/29/32779/163129/640814caF22bb5bfd/775e98ebf88ffdef.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/188395/31/19142/116929/611e1c61Ef3d4b16c/7e0d7de98856601d.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t18742/325/2076691674/145896/81958b38/5ae438d6N7552595a.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/85159/14/23017/35970/6403198fF8c6aaa64/e6126e7673f5989f.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/115084/28/10640/115030/5eef689fE7853978f/c39a4aa2f1276f07.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/148597/36/3693/144858/5f1c0ba9E003f6493/da147b6b8d48178e.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/148451/9/26797/57345/62651dc7E11438e75/1704a3585bb382f1.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/135883/37/27133/113972/61bc0e7aE96f96ce5/be4389d0655359c0.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/133097/14/23406/148619/62074a23E9f12d1ee/09661dea3f5a6b3a.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/117301/16/23819/57483/62738641Ea7197157/33ab241d889f5fe1.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/73373/7/22704/161628/64094d09F4aaf9e9d/49437067ebf0b51b.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/122512/19/35998/125076/64070fecF10a4141b/337f1ae36b935b9f.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/59831/7/11457/143354/5d8d889eE9ea46b71/20c9538449a23307.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/124178/40/35230/37295/640ae0e1Fb3dd7230/d24775e5f39c8d1a.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/199988/27/29322/52576/63552901E06846209/2a0d38da39cb81de.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/188006/6/19099/313360/611f772fE0491ab33/f217b9ada9a13d05.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/162926/29/35240/17537/640aa3d0F8bd4cacb/af34943338ff6ece.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t5860/54/3502917032/88795/c008379b/593bef2dN68a67f9a.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/157813/19/32886/64585/6379db79E426324af/b2f58b480da4a197.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/197075/26/2564/42347/61133abbE6250b6fd/0c0bf8e2146ade69.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/54258/17/22402/24816/6343f9d0E62686ff4/1b4ea727c8e1ad83.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/196704/3/26659/37853/62f0a9f8Ecd6bd5ff/d50db104e01f804b.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/95619/11/34684/72945/640e8ee0F14336d47/a2e696723c576a0b.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/136571/14/7445/66621/5f3ca74eE50d5fc8b/6422aa2178453180.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/165781/29/32779/163129/640814caF22bb5bfd/775e98ebf88ffdef.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/156174/25/19049/30705/60642bafEdbd4f3c5/268a7d1d487797c7.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/30229/25/20455/38706/63e36bb0F0aa41ff3/9d64b2dc5337c0a3.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/73572/34/21867/26127/6307318aEe8c83829/4893ae4a93bd5db7.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/166155/8/35386/92423/63ff1bcfFb36ec4e7/e4ae584b752ea714.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/188395/31/19142/116929/611e1c61Ef3d4b16c/7e0d7de98856601d.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/41382/37/20266/23904/6343fc1cE655ff2b3/e92bf25e473140fc.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/42217/27/20513/142430/64085902Fa39a2fe8/3df21590296872f5.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/196649/34/25931/657907/62a96e09Eb861585b/c1ed72c80f4edc40.png",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/103937/29/32702/150638/63484a15Eaed7e4ac/3771f538cd46ca30.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/217294/11/6829/136671/61af4979Ee3c83eaf/6d9c0bd5d4f770b2.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/115084/28/10640/115030/5eef689fE7853978f/c39a4aa2f1276f07.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/107347/32/12686/132441/5e9920efE7d0b1a4c/3640b7eee373bf88.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/60576/2/24410/66802/64085911Fd4e4ea84/aaa7a9a9b037fba7.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/188006/6/19099/313360/611f772fE0491ab33/f217b9ada9a13d05.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/26219/19/16939/92413/6295ded3Ebef83055/76bc85df5bd8280c.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/126049/17/21183/97412/6260c14dE64ec302f/8d69f2f3005c43b3.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/220819/27/13519/82047/62206d57Ee6d03f52/37a8370805f6275c.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/181970/16/32783/19675/63e209b8F66f8d758/692f9dccafaed5c9.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/93766/31/19451/50674/6266adf2Ec3d3cbf3/abbf70f9e72d70e9.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/82156/8/7203/24308/5d53be4dE2491f3c2/3df18fef02ce36c9.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/89068/37/32955/22274/6404ba32F9235df2b/880fc5c35abdb0b9.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/61412/39/24284/103548/640edc67F819004f1/05285933e6f862ba.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/58596/33/20071/292804/62b136e1E228bd794/6e00efaa7d0abf88.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/190935/36/20904/80698/612dd2e0E9b5cb019/396586a77c109ca0.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/97565/5/31793/18322/6319145cEd950e3b9/805d31b9c0dc2c27.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/191358/4/28564/21397/633293aaEb31cd1ab/6f37355bb8aa88ab.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/142917/5/33963/20412/6400438fFd56f62f1/e2c7453502c0d2c1.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/131046/2/20740/97740/625695a8E3dc3d8d9/927dc64d4726a991.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/196803/34/29881/19984/63511a09E7d62b7d8/fe8d3f590338109f.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/145334/36/15225/123133/5fb882c4E12176659/ade8775decc98ee9.jpg"
        ],
        titles: [
            "【准新机】小米（MI）平衡车俩轮儿童九号平衡车9号智能代步电动车 白色 9新样机 使用里程50-100公里",
            "自营金旗舰 暖气片 小背篓家用水暖钢制叉背卫生间散热器卫浴厨房阳台厕所洗手间壁挂式-600mm高",
            "欧奈斯(ONNAIS)家用办公手动机械锁密码保险柜25-80老式全钢小型防盗钥匙保险箱入墙保管箱 机械款丨高25cm丨商务黑",
            "全新Philips\\/飞利浦 HR1861 HR1858 榨汁机HR1866 水果原汁机 商用",
            "适配飞利浦剃须刀充电器A00390 series1000 s100 s300 s526配件线兆隆 充电器",
            "自营九阳（Joyoung）家用电饼铛 早餐机 煎烤烙饼机 双面加热 悬浮设计 JK-30K09",
            "倾山空肠粉机小型家用不锈钢蒸炉迷你广东拉肠粉撑抽屉式家庭凉皮机 不锈钢单层款【含1个蒸肠粉抽屉】",
            "自营骑炫Q18车载冰箱车家两用宿舍办公室迷你小冰箱冷冻冷藏可结冰 18L",
            "阿洛德暖气片水暖家用铜铝复合暖气片超薄暖气片壁挂式取暖器 集中供暖 铜铝9050-0.6米高-超薄款厚度5cm",
            "飞利浦面条机 HR2355 2356 2369 2359 面板 塑料盖 配件尾货机全新",
            "飞利浦豆浆机 过滤网 HD2051HD2052HD2060HD2070HD2072HD2",
            "自营勃森散热器 BOULSEN 壁挂式铜铝复合暖气片75*75高家用水暖地暖集中散热自采暖散热器 测量金",
            "灯泡 食物保温灯灯泡 食物保温灯泡 250w保温灯泡 250W银色 100-300W",
            "欧比亚暖气片家用水暖钢制散热器片集中自采暖卧室客厅方头圆头钢制50款 高60cm【三柱起拍】",
            "【【尾货】】小米耳机圈铁Pro入耳式有线耳机音乐耳机手机耳机耳麦 圈铁Pro有线",
            "自营新炬XINJU 氧气瓶便携式制氧机 氧气袋家用吸氧机老人氧气机 孕妇氧气呼吸器 高原反应急旅游氧气包1000ml",
            "自营瑞思迈 Resmed呼吸机家用S10 Autoset全自动睡眠医用无创原装进口持续气道正压呼吸舒缓型白色",
            "一炮红 手机拆机工具A .",
            "自营欧姆龙（OMRON）电子体温计家用测温仪 腋下式体温计 温度计婴儿MC-246",
            "doop 甩脂机健身器材家用抖抖机懒人塑形音乐娱乐 W88 舒适型【强效塑形甩脂】/黑金",
            "JTF 儿童电动牙刷3-6-12-13岁充电式自动青少年软毛学生款防水可爱萌趣儿童牙刷小学生初中生用 小黄鸭6刷头|智能安全断电|BBC软毛",
            "虎牌保险柜家用办公指纹密码WiFi全钢可入墙保险箱 45维克灰 虎牌卓尚/触屏密码+TOUCH指纹",
            "鹰时代车载充电器 一拖三扩展手机车用汽车点烟器车充一分三带usb接口 车载充电器",
            "珍格（zhenge） 手机挂绳女款ins风手提手指扣环圈手工编织绳可爱吊坠铃铛手机链挂件手提车钥匙扣 酒红色A铃铛款",
            "高压无线锂电清洗机配件旋转六档可调节喷头增压洗车机家用工具 5档旋转喷头",
            "Apple iPhone 14 Pro Max (A2896) 256GB 金色 支持移动联通电信5G 双卡双待手机Apple",
            "适配飞利浦剃须刀充电器A00390 series1000 s100 s300 s526配件线兆隆 充电器",
            "自营HUAWEI nova 10 青春版 一亿像素超清影像 66W华为超级快充 6.78 英寸臻彩直屏 128GB冰晶蓝 华为手机",
            "全新Philips\\/飞利浦 HR1861 HR1858 榨汁机HR1866 水果原汁机 商用",
            "自营九阳（Joyoung）家用电饼铛 早餐机 煎烤烙饼机 双面加热 悬浮设计 JK-30K09",
            "【准新机】小米（MI）平衡车俩轮儿童九号平衡车9号智能代步电动车 白色 9新样机 使用里程50-100公里",
            "迪士尼（DISNEY）联名f9蓝牙耳机真无线半入耳式超长续航降噪女款 运动音乐耳机跑步vivo华为oppo苹果14通用tws 米色签名款【蓝牙5.2+ENC降噪】",
            "北美电器 （ACA）9新未使用 AB-K20RC面包机 家用全自动多功能和面机辅食机",
            "vivo iQOO U5x 手机 vivo iQOO骁龙680 5000mAh大电池 6.51英寸 星光黑 8+128G",
            "倾山空肠粉机小型家用不锈钢蒸炉迷你广东拉肠粉撑抽屉式家庭凉皮机 不锈钢单层款【含1个蒸肠粉抽屉】",
            "Apple iPhone 14 Pro (A2892) 256GB 金色 支持移动联通电信5G 双卡双待手机Apple",
            "HYUNDAI现代音响音箱家庭影院点歌机套装家庭ktv家用唱歌卡拉OK无线蓝牙功放卡包设备 经典版（下单免费升级10吋音箱）",
            "索尼（SONY）PS4 ps5通用 Slim PRO原装游戏光盘热门大作 游戏软件光碟 对马岛之魂 对马幽魂 对马之鬼 中文",
            "七彩虹iGame GeForce RTX 3070 RTX3080Ultra 3070ti 8G显卡 七彩虹战斧RTX 3070 8G三风扇原包装99新",
            "二手9成新酷睿i3 530 540 i5 650 750 i7 860 四核1156针台式机cpu I5 750 四核2.66G无集显 单CPU 送硅胶",
            "飞利浦面条机 HR2355 2356 2369 2359 面板 塑料盖 配件尾货机全新",
            "群华D2\\/D6\\/T2记录仪配件保护套可360度旋转",
            "自营HUAWEI nova 10 SE 一亿像素质感人像 4500mAh长续航 轻薄机身128GB 10号色 华为手机",
            "JTF 儿童电动牙刷3-6-12-13岁充电式自动青少年软毛学生款防水可爱萌趣儿童牙刷小学生初中生用 小黄鸭6刷头|智能安全断电|BBC软毛",
            "纽曼汽车应急启动电源五防智能线夹 10号CS插头普通电瓶夹直径5mm",
            "华为（HUAWEI）鸿蒙HiLink生态产品适用华为车载智慧屏S50 车机导航一体机3K超广 车载智慧屏S50三摄版（含后视摄像头+降压线）",
            "Nikon/尼康J1套机J2J4J5V1二手微单相机入门机单电迷你数码相机10-30镜头佳能M3 95新尼康J1+10-30镜头 带电池，充电器，肩带，32G卡，相机包，读卡器",
            "得焺 led轨道灯射灯服装店商超展厅射灯家用电视背景墙明装二线导轨灯 两线黑色1米轨道条",
            "全新广发单边铝槽回形顶灯带向上打光线条灯反光灯槽洗顶线性灯双眼皮吊顶 样品",
            "CAFEDE KONA电动奶泡器 咖啡拉花不锈钢自动打奶泡器 手持发泡器 银黑色",
            "Apple 苹果14pro 苹果手机(A2892) 5G 全网通 双卡双待手机 暗紫色 256GB（标配+20w品牌充）",
            "自营九阳（Joyoung）肖战推荐 破壁机家用多功能 降噪预约加热豆浆机早餐机绞肉馅机榨汁机辅食机L18-Y915S",
            "自营飞利浦（PHILIPS）E535 4G翻盖老人手机全网通4G移动联通电信 双屏双卡双待老年机 陨石黑",
            "自营丹拿（DYNAUDIO）汽车音响 ESOTAN 212+212C同轴 全车6喇叭升级改装套餐",
            "自营Apple iPhone 14 Plus (A2888) 256GB 午夜色 支持移动联通电信5G 双卡双待手机",
            "趣器屋5V1A充电头蓝牙耳机通用充电器适用苹果安卓华为小米红米手机usb插头快充typec数据线快速 【1A慢充充电器】适用5V1A设备",
            "（活动专享）Apple 苹果 iPhone 14 Plus (A2888)通5G手机 128GB星光色 官方标配",
            "小霸王掌上游戏机掌机SUP俄罗斯方块生日礼物送男友儿童朋友老公黑科怀旧复古FC街机 小霸王4.1英寸高清屏蓝色",
            "Apple 苹果 iPhone 14（A2884）苹果14 5G全网通手机 蓝色 256GB 官方标配【90天碎屏保】",
            "【二手9成新】佳能 8030/8050 无线 自动双面A4彩色激光打印复印扫描网络一体机家用办公 4色硒鼓一套"
        ],
        prices: [
            "1599.00",
            "363.60",
            "238.00",
            "1888.00",
            "18.90",
            "99.00",
            "95.00",
            "499.00",
            "127.00",
            "106.00",
            "50.00",
            "10.00",
            "27.82",
            "69.00",
            "258.00",
            "12.90",
            "12.60",
            "8800.00",
            "16.60",
            "48.00",
            "389.00",
            "89.00",
            "599.00",
            "15.80",
            "14.90",
            "19.80",
            "12.80",
            "8629.00",
            "18.90",
            "1699.00",
            "1888.00",
            "99.00",
            "1599.00",
            "39.00",
            "249.00",
            "888.00",
            "95.00",
            "7639.00",
            "3099.00",
            "188.00",
            "2499.00",
            "105.00",
            "106.00",
            "59.00",
            "1949.00",
            "89.00",
            "45.00",
            "2739.00",
            "1299.00",
            "15.90",
            "10.00",
            "50.00",
            "8249.00",
            "339.90",
            "399.00",
            "4700.00",
            "7099.00",
            "12.00",
            "6088.00",
            "39.80"
        ]
    },
    '居家优品': {
        // 居家优品
        imgs: [
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/123561/2/36041/23012/63fd6b1eF1ed42457/36a48e19ebeaa7d1.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/94872/10/21144/97588/6400ba32F384afa61/5c312f8e726b703e.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/202790/10/30930/184843/63f575e7F2f0c2e7b/76a9039dbbc3cb82.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/88098/6/21148/40454/63f02289Feb3589d4/55416cde22e960e6.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/67480/18/23893/23135/63fd7e98F1112d5eb/64e5bda9ff153196.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/143624/20/32587/74672/63d47979F5dccefc1/c5cc05f7ae9eae55.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/221546/4/20920/75900/63f6f151Fbc764eef/23f5605f545d040b.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/179053/9/31599/75443/63ec2fd5F963df445/ca42cdf655355c2c.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/184049/39/26139/61441/62b01f05Ed2befca6/f36993b69282369f.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/112470/29/7952/523741/5ec90ca1E9d2b7bc7/070ccd6f6f78ebcc.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/171542/37/30914/918345/634665c1E1bad5c8e/e3af5f1f882522ca.png",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/206269/38/26389/46825/636b7c7dE7a050c76/e189001ea765a4ed.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/196262/11/22968/148084/624d022cE9d0409ab/e2d5dbf0cf6cd54f.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/83478/18/22625/33603/632d52a9E4a34d558/76c915be5068f977.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/38531/7/19700/36095/63380e50E29358fc4/2201acc8dce0b305.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/185444/27/32417/432200/63f5f487F6392735f/89a640cde348eeeb.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/181521/36/31920/304683/63e9fd55Fbf1d3ace/099362a6d8eb06bf.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/145432/26/26115/190404/61cd2db1Efdb4be7e/087416e6159c3b24.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/180400/15/28829/56586/6322cef5E202f8a74/885fdb4fd44bcecb.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/197537/37/17252/191988/6190e58aE443cda37/5a0ebd343d9c3c14.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/128335/16/26767/53868/63b5845eF97d1ec69/2f4b0e673bb46e1e.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/218151/34/23600/375624/63f86759Fb542c57e/715fe80c8616e0f3.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/210238/36/26249/267310/6340221eE01111914/9125985c7aacc409.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/54361/4/22131/90214/6332cda8Ede60ea39/1a75c13e66fc3425.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/166875/31/30595/54447/63340ca8Ec7c4c84e/829dcce506558b68.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/168226/8/27270/460680/6219c38eEeaa25be6/78f107b915ed5ec5.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/115439/17/33149/149076/640f30a9F19388aa1/d953b36b7d612cd0.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/135155/26/27967/92635/638ec1d4E4bd52363/a4d523cd8ec5afd9.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/190231/39/27926/156275/62f71586E6b204c20/2094f7d2667fa40c.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/45177/22/23496/83639/63f5f3d0F47720d4e/7179dfc582a16a52.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/172015/40/32474/99251/63f97eceF3db5b2d1/77ec1ae05532c454.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/198198/39/772/120669/6104c2d7E766f0d8d/6b625e522ed04c8f.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/194128/14/31665/48074/63b3be98F64cf4392/e8503f608fa574f4.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/186017/18/30902/248914/64000c9cF76fcaf74/b3bfa7b3b1ccfbf1.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/81832/23/19615/238613/62a08755E72f5a150/2d774675329a6053.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/162337/37/29092/76978/62e6490cE89c29938/9fcd527464df4df0.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/85336/38/32736/98650/63fc61c4F24313844/f0b9e1383224351a.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/143751/14/30607/147594/6355e63dE1e7aea36/e38ca1915202c31d.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/1822/10/20412/165020/63292016E1dc9e6fb/a730a42db4b8d44a.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/207382/27/23962/47366/636ca1baEa74737b3/75f5b5abe58f234d.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/184875/12/17951/246668/6113e5dcEc0eaeb67/05dd61f2e199dc67.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/168549/31/11019/135295/60472492E2ae30c17/8203f756e4fd472f.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/129849/25/29583/91741/63339ba7E2fbe4432/6e4fae1c3685aeb0.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/5400/24/19289/129455/640adce2Fa80ae1b8/c048bd048cba7dc1.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/185005/36/33014/168413/63faf671Fe667566e/56b364acd1f2748c.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/101879/7/37015/89112/63ed9876F423f42a5/0a37230d1cfa6bb2.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/206711/4/19772/151172/624e3843Ef798c3bf/a481615110e11e22.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/44616/3/23897/152429/63d75537Fa93186a0/20beca3bacc6439d.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/87905/16/20065/120861/640bec4dF41d8da3b/4759852c1da3505e.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/136617/8/1036/157454/5ed4b2a2Ef07427e3/5529c5f748cc3507.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/123561/2/36041/23012/63fd6b1eF1ed42457/36a48e19ebeaa7d1.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/202790/10/30930/184843/63f575e7F2f0c2e7b/76a9039dbbc3cb82.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/67480/18/23893/23135/63fd7e98F1112d5eb/64e5bda9ff153196.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/94872/10/21144/97588/6400ba32F384afa61/5c312f8e726b703e.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/166875/31/30595/54447/63340ca8Ec7c4c84e/829dcce506558b68.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/214887/38/21628/216203/6335742eE40b9d367/1820e78b49f03faf.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/129849/25/29583/91741/63339ba7E2fbe4432/6e4fae1c3685aeb0.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/162789/10/30362/69784/640e93e2F66f9b075/4a8eaf3825ab702f.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/179053/9/31599/75443/63ec2fd5F963df445/ca42cdf655355c2c.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/88098/6/21148/40454/63f02289Feb3589d4/55416cde22e960e6.jpg"
        ],
        titles: [
            "毛笔手写字画定制演觉法师书法慈悲喜舍收藏名人字画客厅装饰画临摹 画芯不含装裱34*138cm",
            "【带装裱】潮流艺术家 有解的山姆《夏至未至》签章版 限量版画 夏至未至 40*50cm黑色铝合金拉丝边框+有机玻璃",
            "假一赔三 永久保真【带合影】中央美院教授 凌雪 《和和美美》纯手绘国画花鸟客厅挂画",
            "宜兴紫砂壶工艺美术师鲍老师原矿天青泥【仿古】容量240cc",
            "字画定制周先生慧珺书法天道酬勤手绘收藏名人字画客厅装饰挂画临摹 画芯（不含装裱）尺34*138寸cm",
            "自营稳健（Winner）医用外科口罩50只/盒 三层防护含熔喷层防细菌花粉 细菌过滤率大于95% 抽取式盒装设计",
            "佛教协会副会长坚赞诺布手写书法一物一拍所见即所得孤品带机构鉴定收藏证书宣纸原稿画芯吉祥如意",
            "九阳（Joyoung）保温杯女士高颜值儿童学生水杯大容量家用保温水壶吸管大肚杯",
            "自营宠翰 宠物刮毛器粉色 猫咪宠物刮毛器除毛神器吸毛器地毯刮狗毛清理器刷毛去猫毛粘毛器",
            "自营奥美优 种菜盆 阳台室内蔬菜种植盆 12L加厚塑料长方形花盆 家庭种菜庭院养花盆 带托盘 LZ7312",
            "陈一凡 【买2件=发3罐】 毛尖茶叶绿茶新茶 雨前浓香型罐装100克",
            "自营百乐（PILOT）BXRT-V5按动中性笔签字笔彩色水笔 0.5mm考试财务笔 黑色",
            "博曼斯（BOMANSI） 304不锈钢保温饭盒可微波炉加热便当盒上班族成人儿童学生餐盒 双层3格饭盒+保温袋+小麦勺筷",
            "领克（Lynk&Co）2022赛季房车世界杯限定版-Baby赛服 白色 80码(建议身高74-78cm)",
            "自营觅锐马桶抽子吸皮搋子水拔子疏通厕所坐厕蹲厕下水道疏通器 绿",
            "宋代古钱币闻德公博评级圣宋元宝评级币E222",
            "自营悦卡洗车拖把 汽车掸子擦车拖把刷车刷子软毛工具用品可伸缩洗车刷-蓝",
            "东之天地 亚克力透明水果盘酒店酒吧KTV客厅水果拼盘家用塑料干果零食瓜子碟子厨房甜品点心盘蛋糕盘茶盘 水果盘/2个装/直径25cm",
            "自营蜂翼 苹果14pro手机壳 iPhone14promax保护套镜头全包透明防摔男女时尚潮款壳 牛奶白",
            "自营IAM City Farmer 薰衣草 DIY趣味种植盆栽 多年生花卉种子 桌面盆栽 芳香植物 办公室桌面创意盆栽",
            "附国检证书 藏传极品朱砂鎏银九眼马蹄纹天珠",
            "自营卡游 奥特曼卡片豪华版WCR卡GP卡SP金卡拼图满星卡牌儿童玩具生日礼物",
            "陈一凡 茶叶 小青柑普洱茶 正宗生晒新会小青柑陈皮云南宫廷普洱茶熟茶柑普茶28粒礼盒装250g",
            "【作者授权】中书协会员 张恩亭 【沁园春 雪】180x96cm纯手绘书法水墨画国画 50",
            "全款 别克buick GL8 ES陆尊 653T 豪华型和悦版",
            "自营IAM City Farmer 虞美人 DIY植物种植趣味盆栽 网红植物 桌面盆栽 科学课观察植物 创意亲子种植 小盆栽",
            "自营尚美德卫生间置物架 太空铝免打孔厕所洗手间收纳架挂件浴室置物架",
            "一套六个牛角酒杯，选材上乘，雕工精细，器型优美，纹理清晰",
            "自营小猪佩奇毛绒玩具公仔玩偶女孩安抚包包挂件生日礼物女 19cm佩琪",
            "刘喜兴 《国粹》 布面油画",
            "自营悠梵萌小花盆方形多肉播种盆彩色八角小方盆栽花盆大号10个装颜色随机",
            "自营好族 HAOZU 汽车内饰用品车上前座后排纸巾盒雨伞收纳兜袋置物箱车载垃圾桶",
            "【包老带证书能典当44】彩陶双耳罐（十四）",
            "自营清风抽纸 纸巾 2层200抽软抽*20包（整箱售卖）新老品随机发货",
            "自营九千谷 育苗盆 发芽盆水培蔬菜设备保温带盖豌豆苗种植架无土栽培托家用芽苗菜育苗盘7017",
            "微光里 现代简约抽象莫兰迪创意陶瓷花瓶简约水培磨砂花器小清新花瓶摆件 思考者人像花瓶-杏黄",
            "山东省美协 王绍德《富水长流》书法水墨画字画书画中国画花鸟艺术品山水画家纯手绘画",
            "自营艾杰普 防撞角透明桌角防撞角茶几防磕碰包角硅胶儿童边角保护角-20只装",
            "厨滋味 简约水果盘 家用创意糖果盘零食盘烫金边塑料果蔬盆干果托盘客厅零食收纳盘置物盘轻奢风点心盘 水果盘【祖母绿】",
            "自营富居(FOOJO) 挂钩 【70丝/20只装】强力粘钩 无痕免打孔挂钩贴 浴室强力粘钩贴 钥匙毛巾抹布无痕贴",
            "不会凋谢的满天星北欧ins小清新干花束组合满天星真花桌面家居装饰摆件 (文心兰/狂欢)组合 不含花瓶 干花包",
            "自营雅集茶包袋一次性玉米纤维过滤茶包抽绳花茶茶叶包120片",
            "自营传祺 GS8 2022款双擎系列2.0TM四驱尊贵版（7座 典雅黑 深内饰)",
            "自营振德（ZHENDE）一次性口罩3d立体防护口罩 成人黑色M码30只/袋 轻薄透气立体显瘦亲肤柔软 三层防护防尘",
            "新品特惠带装裱当代艺术家朱永琢限量版画收藏客厅餐厅玄关卧室装饰画挂画",
            "宜兴紫砂壶正高工郭老师原矿底槽清【龙凤掇只】容量430cc",
            "自营华元宠具（hoopet）剑麻抓柱猫爬架小型猫树猫咪用品麻绳猫抓板跳台猫爬柱磨爪猫玩具转盘逗猫爬架玩具",
            "自营Hape(德国)儿童早教玩具开心农场游戏盒男孩女孩节日礼物 E1810",
            "自营尚岛宜家 150只中号加厚加宽手提式一次性垃 圾袋50*65cm*5卷背心黑色袋子",
            "自营恰好时光 北欧手工编织草编篮子 田园风插花花盆 柳编藤编花篮 中号带盆",
            "毛笔手写字画定制演觉法师书法慈悲喜舍收藏名人字画客厅装饰画临摹 画芯不含装裱34*138cm",
            "假一赔三 永久保真【带合影】中央美院教授 凌雪 《和和美美》纯手绘国画花鸟客厅挂画",
            "字画定制周先生慧珺书法天道酬勤手绘收藏名人字画客厅装饰挂画临摹 画芯（不含装裱）尺34*138寸cm",
            "【带装裱】潮流艺术家 有解的山姆《夏至未至》签章版 限量版画 夏至未至 40*50cm黑色铝合金拉丝边框+有机玻璃",
            "全款 别克buick GL8 ES陆尊 653T 豪华型和悦版",
            "自营IAM City Farmer迷你世界 向日葵 迷你盆栽 儿童种植盆栽套装 趣味种植植物观察 diy种植盆栽 女孩玩具",
            "自营传祺 GS8 2022款双擎系列2.0TM四驱尊贵版（7座 典雅黑 深内饰)",
            "定金 【订金】吉利 熊猫 mini 666元下订购车送200元电子购物卡抽千元红包",
            "九阳（Joyoung）保温杯女士高颜值儿童学生水杯大容量家用保温水壶吸管大肚杯",
            "宜兴紫砂壶工艺美术师鲍老师原矿天青泥【仿古】容量240cc"
        ],
        prices: [
            "116.00",
            "228.00",
            "188.00",
            "760.00",
            "117.00",
            "15.90",
            "15.10",
            "500.00",
            "169.00",
            "15.90",
            "17.90",
            "29.80",
            "28.00",
            "13.32",
            "69.90",
            "298.00",
            "12.00",
            "58.00",
            "29.90",
            "27.80",
            "38.00",
            "45.00",
            "42.70",
            "450.00",
            "59.90",
            "49.80",
            "998.00",
            "380061.00",
            "45.00",
            "42.70",
            "19.90",
            "18.90",
            "998.00",
            "19.90",
            "2200.00",
            "19.00",
            "17.00",
            "59.00",
            "57.20",
            "2999.00",
            "44.90",
            "16.60",
            "39.00",
            "661.00",
            "19.90",
            "19.80",
            "10.90",
            "9.90",
            "55.00",
            "22.90",
            "244800.00",
            "14.90",
            "159.00",
            "5000.00",
            "29.70",
            "1099.00",
            "11.90",
            "25.00",
            "116.00",
            "188.00"
        ]
    },
    '超市百货': {
        // 超市百货
        imgs: [
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/146818/24/33368/108111/640fcd04F83db2c3d/bc362b4021590549.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/195907/7/27495/181080/635a3c4dEc7fe4eee/215c0c00a340a397.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/214887/38/21628/216203/6335742eE40b9d367/1820e78b49f03faf.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/195329/17/33044/114791/640018d1Ff4ef2b4d/b3a2558a850f864a.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/162244/16/36616/85204/641032b8F99fd571c/b5d9970d0df18d7e.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/83998/38/24585/71296/63d4c993F76131d3d/342ac560fe5041aa.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/188622/35/25241/450720/62a0a7dfE5e2e7f39/9a5d576898472bef.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/70948/40/21976/47769/640847d2F464c887c/a219ac5a9493ce7e.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/187343/31/32966/84780/63f85458Ff03182e6/c26ac6a2f83b2084.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/169916/33/35989/135068/640fccdeFac185466/5c9879dfa70cf69f.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/63748/31/22887/63289/638ef785E5a1bd343/b236e28aa6ea11c0.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/128387/12/30965/99374/6409f3f0F1b8662cf/00777ee15168b457.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/131473/9/29271/116754/6409abe2F60b3d29f/25313cf54c1fada8.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/85297/14/32590/102856/640a7fc9F2e8059dd/829c57011dda586c.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/50170/38/23715/148073/640e9bf1Fa8f5719a/795443036a560df3.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/219165/33/13202/283630/6215e8b4Ea86fb76e/4279620e9e2f81a4.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/28844/14/19777/335049/631179ebEf657831f/b6b72bd2f2201997.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/82306/32/19302/179202/62b28b00E861a72df/62c7e183f5364e55.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/88371/29/31261/160828/6315a2a8E719d31fc/35348c4a86166929.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/87115/12/32146/182330/63fc788aF396939a2/43dcc090a485bdf6.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/137156/28/32057/99568/6368c993Ef2d6deb8/0f7faf63049ce341.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/138454/28/33178/92160/64085d81F9f7f1495/f5a7330183627996.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/210238/36/26249/267310/6340221eE01111914/9125985c7aacc409.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/96587/39/31100/212004/62ce87e8E3abf87c5/39d92754512065a2.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/121568/25/31632/86444/63f88fdeFb077e640/6309b5217031fbc4.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/197199/20/31015/43819/63f383d8F095cfe48/0ac9c1bff0c109d5.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/158884/18/35167/81432/64093811F099d35d7/517ed586add0af6e.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/183941/33/7044/124589/60b756c7Eadd7e7af/08f88687e04cdd4f.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/19660/2/17018/117252/64085821F3ca87cab/32bd3809c6ce2257.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/102287/30/21294/46233/6392bf72E6650d12e/3d5cae0c0e7c5842.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/169947/18/34552/79079/63e9c833F2b52ffdc/28a91223ba9ac16b.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/114454/14/29513/116596/6364e994E68ca26d4/4e173f37d923f4f1.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/89199/38/19095/202476/615291d1E57d98f11/7a1903cb2d9cd631.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/185056/35/12515/486428/60e29eecEa3c23314/1b6dd2c3e890cc38.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/124573/31/27262/157752/636368aaE2669536f/4e3cfe064e5ffe42.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/190231/39/27926/156275/62f71586E6b204c20/2094f7d2667fa40c.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/180488/13/22257/262021/6246d2e1Ef005b63f/4cc9d86e0304d53f.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/159919/31/24263/108179/61df8f31Eebf1f3bb/66fe30449def113c.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/101830/33/27565/144667/636e7242Ebb06efc1/d28d9d1b79c3cf89.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/216057/17/24056/147451/640fcbf1F01fa76d1/c55c4abba6dcdb45.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/219199/4/10283/238130/61d685bbE940cae85/a1aadb71038414c2.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/163223/39/34492/227437/63c4a1bdFa7e61c99/aa390019be7093b8.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/99558/10/33504/105328/63510487Eeb7edbd6/e5c9b23bcd2e286b.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/171401/36/35740/72157/640fd0e0Fda753dc9/3456955d82101e56.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/124578/5/34647/97774/63afe92dFd7f90413/ed1e215d88273c03.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/177606/30/28950/76414/63350972Eb70a3f7d/05c50db7d8003f97.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/88481/20/34904/82516/640c0b0cF7433d781/d2d317af24f72bfe.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/222841/39/6244/133576/61bad6c8E832088d2/d5a2b87cff334f8d.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/112288/26/32447/185612/63fdd173F43ed9b6b/3d90d85407981e1c.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/82470/32/23914/73251/6406e4a6F27f7098d/b628a4ef1b62c8b0.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/174378/39/33298/76940/640ade3fFf506346b/1304dd09cf92cb85.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/217578/31/2949/132699/6181ecdfE97fc8298/2be9f5639cdc2fbc.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/103194/20/31684/113732/632ebf3cE0f782c14/771b8c741fcea835.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/107202/31/25570/129691/63ef4822F596a1dfe/ef9dd69c175b62d5.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/49104/1/17514/162293/63bd1524Fb1e6c787/357939a638d4cd0b.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/92035/39/31826/170980/636ef8dbE6dfb6ca7/ef91ad9202b7abba.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/153124/40/10255/205988/5fd9a08aE959fb686/6ad324c942db7e20.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/130795/9/31811/113790/640e7d73Fc6a6865e/712367f14e6addf0.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/30744/6/17172/121399/641045d2F259f1e29/5854ad422c2a72de.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/59069/10/21539/35750/62f716b7Ee0bedb94/8555634dda25ee2b.jpg"
        ],
        titles: [
            "自营海氏海诺 一次性医用外科口罩 无菌三层外科灭菌口罩医用 50只独立包装 口罩防尘防花粉（二类医疗器械）",
            "自营红塔 水果罐头 糖水黄桃罐头 425克×6罐 黄桃对开 水果罐头",
            "自营IAM City Farmer迷你世界 向日葵 迷你盆栽 儿童种植盆栽套装 趣味种植植物观察 diy种植盆栽 女孩玩具",
            "自营海氏海诺 一次性使用医用外科口罩100只 无菌三层平面型防尘成人口罩医用面罩 灭菌级10只*10袋",
            "自营博锐剃须刀电动刮胡刀男士全身水洗两刀头胡须刀干湿双剃便携快充车载剃胡子刀 PS181",
            "自营保赐利除胶剂 去胶清洗剂汽车玻璃不干胶双面胶粘胶清洁去除剂神器450ML",
            "自营日清 方便面 合味道6口味 74g*12杯混合整箱装 桶装速食方便面泡面",
            "自营凡米（FANMI）耳温枪电子体温计额温枪医用级婴幼儿童家用数字测温仪【无需耳套 成人婴儿两用丨德国3D探头】",
            "自营金龙鱼 长粒香大米 东北大米 10kg",
            "自营荣事达（Royalstar） 榨汁机 便携式无线迷你榨汁杯家用小型搅拌杯料理机果汁机 RZ-68V7A",
            "自营觅时光 木杆棉线拖把 排拖普通老式墩布拖布加宽头棉拖把工厂家尘推50cm",
            "自营果仙多维果泥 婴幼儿辅食 蓝莓苹果雪梨混合口味 儿童水果汁泥100g 6个月+",
            "自营界面医用N95口罩成人防护灭菌级防尘防细菌双层熔喷布独立包装 白色25只",
            "汉美驰（Hamilton Beach） 美式滴漏式咖啡机泡茶机便携手冲家用办公室小型全自动一体机 美式滴滤 美式咖啡机49981-CN",
            "贞喜气儿童浴巾游泳斗篷带帽吸水男女宝宝洗澡浴袍小黄鸭沙滩玩水夏季 经典鸭70*150",
            "自营燕花姬 冲饮谷物 奇亚籽坚果藕粉 营养早餐方便速食冲饮代餐颗粒状易冲泡500g/罐",
            "自营好汽仕（Howtreats）钛合金汽车钥匙扣个性简约男士挂件钥匙链圈环锁腰挂奔驰宝马奥迪大众本田丰田凯迪拉克",
            "自营科林青香免洗去渍笔 去污笔 去油渍 便携魔法去污笔 衣物清洁 应急神器去渍笔 9m/支去渍笔",
            "自营杨过 一口生煎230g/袋（10只）拇指生煎包 苏州名点 速食早餐早点",
            "自营葡记蓝莓乳酸菌味吐司面包1000g 欧包夹心点心手撕面包送礼",
            "自营娃哈哈 AD钙奶 含乳饮料 220g*20瓶 整箱装 （新老包装随机发货）",
            "自营邦力健 多普勒胎心仪 胎心监测仪 医用胎音监护仪 孕妇家用听胎心 数字款",
            "陈一凡 茶叶 小青柑普洱茶 正宗生晒新会小青柑陈皮云南宫廷普洱茶熟茶柑普茶28粒礼盒装250g",
            "轩沁轩香挪车电话牌临时停车手机号码牌车载隐藏式汽车移车电话号码牌用品 科技黑【合金材质一键隐藏】",
            "自营小葵花小儿止咳贴 儿童感冒咳嗽化痰贴 支气管炎穴位理疗远红外磁疗贴 4贴/盒",
            "自营京鲜生 泰国金枕头冷冻榴莲肉300g装 冷冻榴莲",
            "自营海氏海诺 N95级医用防护口罩 独立包装无菌30只 一次性n95型口罩医用灭菌防尘成人白色国标正品gb19083-2010",
            "自营湾仔码头 经典鲜美猪肉小笼包早餐包子早茶生鲜速食速冻面点 300g 12只",
            "自营植护抽纸 气垫纸巾4层360张*20大包整箱 餐巾纸抽 婴儿面巾擦手纸",
            "自营RAOYI 护龈软毛牙刷 纤柔软毛牙龈出血敏感护龈牙刷10支家庭装",
            "自营尔蓝 对折胶棉拖把 吸水海绵拖布免手洗懒人墩布家用干湿两用 AL-JM06",
            "自营博尔改新交规车牌架框汽车牌照框不锈钢车牌边框保护托盘车牌底托套装",
            "e-zhi网红玩具会跳舞的猪小屁0-3婴幼儿1周岁儿童生日礼物送男孩4-6岁 猪小屁-彩纸包装【电池款】",
            "自营俄瓦斯号哈尔滨风味红肠220g 果木熏香肠腊肠火腿肠熟食腊味东北特产即食",
            "自营旺旺 旺仔牛奶 儿童早餐奶 原味 礼盒装 125ml*24包",
            "自营小猪佩奇毛绒玩具公仔玩偶女孩安抚包包挂件生日礼物女 19cm佩琪",
            "自营煦贝乐 儿童贴纸大号手提双层蕾丝裙公主换装3d立体泡泡贴画玩具女孩时装娃娃换装奖励贴画生日节日礼物",
            "自营爱特福84消毒液1.25L 居家消毒水消毒剂 杀菌洁厕地板清洗 消毒常备",
            "自营日照绿茶茶叶2022年新茶有机绿茶一级铁桶简装500g浓香型栗香味山东特产",
            "自营雪花啤酒（Snowbeer） 晶粹 330ml*6听",
            "自营阿榴哥泰国进口金枕头冷冻榴莲果肉 300g 冷冻榴莲",
            "自营比比赞（BIBIZAN）乳酪肉松吐司800g夹心面包营养早餐学生抗饿休闲零食",
            "自营燃烧吧大脑鲁班立方磁力积木魔方儿童礼物节目组指定衍生品基础版炫彩儿童礼物",
            "汉弥尔敦 婴儿推车可坐可躺轻便一键折叠可登机宝宝手推婴儿车 X1仙踪绿",
            "自营九安医疗 上市大品牌 iHealth电子体温计 成人宝宝儿童婴幼儿口腔腋下家用医用体温计",
            "自营稳健（Winner）一次性3D立体幼童口罩1-3岁小孩分龄防护20袋/盒 独立混装卡通印花高透低阻亲肤透气",
            "自营小熊（Bear）烧水壶电水壶热水壶电热水壶开水壶1.5L大容量养生304不锈钢内胆双层防烫ZDH-Q15U8",
            "自营英科 樱桃小丸子一次性口罩卡通联名款独立包装成人三层防护口罩 20只/盒",
            "自营百草味 去骨鸡爪75g 柠檬酸辣去骨鸡爪脱骨凤爪即食袋装零食",
            "自营灵动宝宝儿童玩具电动翻滚老虎新生儿早教音乐男孩女孩3-6-12个月生日礼物",
            "自营振德（ZHENDE）一次性口罩3d立体口罩 成人白色M码30只/盒 轻薄透气立体显瘦亲肤柔软 三层防护防尘",
            "自营安井 糯米大烧卖 1kg 约20个烧麦 家庭装面点早餐 加热即食早茶点心",
            "自营熊猫熊抱枕公仔毛绒玩具女孩宜阿呜家啊呜鲨鱼玩偶布娃娃女生睡觉抱枕长条儿童男孩女神节生日礼物条条同款",
            "自营富春 三丁包300g 6只早餐包子 扬州包子速冻蒸包 笋丁鸡肉包猪肉包",
            "婴蒂诺（infantino）宝宝早教启蒙自由拼搭建玩具婴幼儿抓握训练多形态欢乐套装",
            "自营奥智嘉 彩泥橡皮泥超轻粘土儿童玩具男孩女孩手工DIY面条机黏土雪糕机模具工具过家家套装生日礼物",
            "自营鑫思特儿童合金工程车挖掘机轨道集装箱停车场玩具车仿真吊塔模型男孩玩具套装生日礼物",
            "自营美的（Midea）智能料理机多功能易清洗榨汁机家用搅拌机果汁机婴儿辅食机WBL2501B",
            "自营飞利浦（PHILIPS）男士电动剃须刀干湿双剃刮胡刀新3系升级款S3203/08 【送男友 送老公】",
            "自营小猪佩奇毛绒玩具抱枕公仔潮玩布娃娃猪猪玩偶生日礼物女 30cm乔治"
        ],
        prices: [
            "22.90",
            "34.90",
            "15.00",
            "14.20",
            "18.80",
            "39.90",
            "11.20",
            "52.90",
            "199.00",
            "59.90",
            "44.00",
            "24.90",
            "12.80",
            "34.90",
            "469.00",
            "39.90",
            "24.80",
            "22.90",
            "17.90",
            "15.90",
            "19.90",
            "29.90",
            "37.80",
            "79.00",
            "49.80",
            "28.90",
            "25.60",
            "39.90",
            "48.80",
            "47.80",
            "19.90",
            "41.90",
            "40.90",
            "26.90",
            "24.90",
            "13.90",
            "26.00",
            "24.80",
            "68.00",
            "16.50",
            "62.90",
            "19.90",
            "32.90",
            "30.80",
            "13.80",
            "199.00",
            "16.50",
            "39.90",
            "24.90",
            "21.90",
            "59.00",
            "2999.00",
            "2849.00",
            "19.90",
            "17.90",
            "28.80",
            "59.00",
            "15.80",
            "13.80",
            "13.20"
        ]
    },
    '时尚达人': {
        // 时尚达人
        imgs: [
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/179630/1/15505/85581/60fc00acE5f26adb4/1a6aac939494226f.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/80100/15/22048/131280/6305bb3cEe81f4424/bad5566488a28848.png",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/213323/10/18940/67305/627cc711E5aec4eac/d29c68bbd461d7ec.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/42571/26/20049/323668/63492247E64190b38/556d34e0240d6f67.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/155741/6/13056/246564/60423917E90fca11b/708244b2a9f7d0ab.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/132974/27/31667/17213/63871c21Ec92ce7dc/db238b2a951f8369.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/46618/17/21538/152765/6400bce5Fe02f8246/91d3c47c4e3ad518.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/17035/34/16841/38840/63bcc292F20fdb3eb/3d3a4a8665eca7bb.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/213599/10/1992/611016/6178c6b4E2162aaff/c4a0d55b23e73fba.png",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/5089/21/13839/295717/5bd91713E0c842868/14031bc0b89162c5.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/133742/37/24828/161937/62c97c35Eb10d70c0/7f2186469eae4a7b.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/110200/26/31143/52958/63e73effF0bb0344f/670715028ecdccbd.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/114883/2/32415/26609/63f58ffcF286cbccf/6de2d8587dfe8313.png",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/160227/10/34528/23959/63e75accF4eab32da/1cd5e0b95b17f476.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/147362/13/19615/282886/60a902dfE95e90e5e/f716cfe828315231.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/174728/12/34040/15207/63f1e252F5bb9f8a1/854adc324254571d.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t18865/20/1957273376/794382/2fd613d9/5adcc4a9N1a650f44.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/201816/38/24507/67395/62fc9523Ef4bed51b/6de5525df30dc995.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/84987/9/32441/174468/63918802Ed2a5b769/d4809169f0030331.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/105040/26/30326/33361/62c28773Ede45e399/d131d5a576d5c3bc.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/199247/22/27619/126452/63171879E10dfd91a/1087b8f7953ce691.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/38950/6/10275/135111/5d19ae9bE698191a5/626b2dbc57c2e339.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/112615/17/22433/342995/6229f151E11c4119b/8de6551efc206251.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/139926/33/10561/162244/5f86ba2cE3f1b1a46/ae662ec131e9bdc6.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/74325/26/24332/43598/63e75265F8092e09e/d384c3c5eda05c60.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/179630/1/15505/85581/60fc00acE5f26adb4/1a6aac939494226f.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/80100/15/22048/131280/6305bb3cEe81f4424/bad5566488a28848.png",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/213323/10/18940/67305/627cc711E5aec4eac/d29c68bbd461d7ec.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/42571/26/20049/323668/63492247E64190b38/556d34e0240d6f67.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/155741/6/13056/246564/60423917E90fca11b/708244b2a9f7d0ab.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/132974/27/31667/17213/63871c21Ec92ce7dc/db238b2a951f8369.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/17035/34/16841/38840/63bcc292F20fdb3eb/3d3a4a8665eca7bb.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/213599/10/1992/611016/6178c6b4E2162aaff/c4a0d55b23e73fba.png",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/5089/21/13839/295717/5bd91713E0c842868/14031bc0b89162c5.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/133742/37/24828/161937/62c97c35Eb10d70c0/7f2186469eae4a7b.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/110200/26/31143/52958/63e73effF0bb0344f/670715028ecdccbd.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/114883/2/32415/26609/63f58ffcF286cbccf/6de2d8587dfe8313.png",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/160227/10/34528/23959/63e75accF4eab32da/1cd5e0b95b17f476.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/147362/13/19615/282886/60a902dfE95e90e5e/f716cfe828315231.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/174728/12/34040/15207/63f1e252F5bb9f8a1/854adc324254571d.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/214650/5/23363/178266/636a176bE0ac9b7e5/9d6f704c2cbd4837.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t18865/20/1957273376/794382/2fd613d9/5adcc4a9N1a650f44.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/201816/38/24507/67395/62fc9523Ef4bed51b/6de5525df30dc995.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/84987/9/32441/174468/63918802Ed2a5b769/d4809169f0030331.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/105040/26/30326/33361/62c28773Ede45e399/d131d5a576d5c3bc.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/199247/22/27619/126452/63171879E10dfd91a/1087b8f7953ce691.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/38950/6/10275/135111/5d19ae9bE698191a5/626b2dbc57c2e339.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/112615/17/22433/342995/6229f151E11c4119b/8de6551efc206251.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/139926/33/10561/162244/5f86ba2cE3f1b1a46/ae662ec131e9bdc6.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/74325/26/24332/43598/63e75265F8092e09e/d384c3c5eda05c60.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/179630/1/15505/85581/60fc00acE5f26adb4/1a6aac939494226f.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/80100/15/22048/131280/6305bb3cEe81f4424/bad5566488a28848.png",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/213323/10/18940/67305/627cc711E5aec4eac/d29c68bbd461d7ec.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/84987/9/32441/174468/63918802Ed2a5b769/d4809169f0030331.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/155741/6/13056/246564/60423917E90fca11b/708244b2a9f7d0ab.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/42571/26/20049/323668/63492247E64190b38/556d34e0240d6f67.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/147362/13/19615/282886/60a902dfE95e90e5e/f716cfe828315231.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/17035/34/16841/38840/63bcc292F20fdb3eb/3d3a4a8665eca7bb.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/132974/27/31667/17213/63871c21Ec92ce7dc/db238b2a951f8369.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/5089/21/13839/295717/5bd91713E0c842868/14031bc0b89162c5.jpg"
        ],
        titles: [
            "【新品特惠】大嘴猴（Paul Frank）保温杯马克杯套装四件套情侣组合 PFC761T 高端礼盒装",
            "Zippo正品夜光流沙打火机情人时尚礼物炫酷收藏送男友送女友抖音款5色透明外壳新潮创意",
            "印尼沉香20mm手串雕刻《六字真言》克重20g高端大气男款送礼自戴",
            "置衣堂袜子男士长筒袜秋冬季ins街头风运动吸汗透气学生篮球高帮长袜男字母街头 混色5双装 均码",
            "四季平安豆 大叶黄杨木尺寸，总长11，长4，宽2.5，厚1，厘米",
            "GUCCI 古驰 Gucci眼镜 男士金属框架太阳眼镜 蓝色 GG1099SA 002",
            "牡达斯女鞋2023春季新款溶解小白鞋女防滑厚底板鞋女增高百搭休闲运动鞋 F600白卡 37",
            "卡洛特（KLUOT）穿戴甲片 美甲贴片指甲片假指甲片可穿戴可拆卸果冻胶 穿戴甲24片 车厘子红【含工具包】",
            "【全新未使用】新秀丽 旅行收纳袋 大容量洗漱包男女674",
            "火树 999足金黄金戒指女转运珠小金珠本命年红绳金戒指男女款情侣指环金豆豆虎年硬金属虎 金重约0.22g(送检测报告)",
            "铂兰芝（BOLANZHI）3条装 内裤男无缝舒适透气中腰男士四角裤蜂巢男士平角裤 灰蓝色+中灰色+浅灰色 均码(建议80-130斤)",
            "非洲小叶紫檀0.8*108粒搭配狮子头送礼自戴",
            "李宁游泳包干湿分离防水袋子斜跨手提健身男泳裤收纳袋大容量泳包 753黑红色【可放拖鞋】 干湿分离",
            "李宁单肩包男包女包官方新款训练系列运动包ABDS615 黑色 150*85*200mm",
            "【附国检鉴定证书】小叶紫檀0.8*108颗蝴蝶手链男女款佛珠手串盘玩把玩文玩拍卖",
            "即势美式冲锋衣外套男女春秋季学生户外防风防水三合一飞行夹克外套男 黑色【连帽可拆6266】 XL",
            "俞兆林【10双】袜子男士春夏季棉袜吸汗透气运动短袜布标男袜日系船袜学生袜浅口潮袜 外星时尚布标男袜10双装 39-43",
            "缅甸花梨龙凤呈祥果盒24*24*8.5cm经久耐用餐桌实用摆件",
            "打火机zippo纯铜限量版女士送男友煤油款砂轮防风不含气创意黄铜深雕双面极速机车",
            "特价 半钛近视眼镜框男士潮全框眼睛架可配眼镜近视镜超轻女护目镜大框镜架时尚简约商务",
            "紫光檀 雕刻虎头2.0x12颗手串 跑环 夜光石男款送礼自戴",
            "左右良品凉鞋女水晶护士洞洞鞋女2023春季新款沙滩防滑厚底孕妇果冻护士鞋 牡蛎金 37",
            "发簪黑檀木雕刻木簪古风簪子盘发古装头饰木质木制手工 弄梅 18CM",
            "纽百盾劳保鞋男士ins超火男潮老爹鞋钢包头防砸防刺穿轻便软底防臭增高安全鞋 515战斗黑【防砸防刺】【标准码】 40",
            "珂旭弹力圈珍珠手镯",
            "【新品特惠】大嘴猴（Paul Frank）保温杯马克杯套装四件套情侣组合 PFC761T 高端礼盒装",
            "Zippo正品夜光流沙打火机情人时尚礼物炫酷收藏送男友送女友抖音款5色透明外壳新潮创意",
            "印尼沉香20mm手串雕刻《六字真言》克重20g高端大气男款送礼自戴",
            "置衣堂袜子男士长筒袜秋冬季ins街头风运动吸汗透气学生篮球高帮长袜男字母街头 混色5双装 均码",
            "四季平安豆 大叶黄杨木尺寸，总长11，长4，宽2.5，厚1，厘米",
            "GUCCI 古驰 Gucci眼镜 男士金属框架太阳眼镜 蓝色 GG1099SA 002",
            "卡洛特（KLUOT）穿戴甲片 美甲贴片指甲片假指甲片可穿戴可拆卸果冻胶 穿戴甲24片 车厘子红【含工具包】",
            "【全新未使用】新秀丽 旅行收纳袋 大容量洗漱包男女674",
            "火树 999足金黄金戒指女转运珠小金珠本命年红绳金戒指男女款情侣指环金豆豆虎年硬金属虎 金重约0.22g(送检测报告)",
            "铂兰芝（BOLANZHI）3条装 内裤男无缝舒适透气中腰男士四角裤蜂巢男士平角裤 灰蓝色+中灰色+浅灰色 均码(建议80-130斤)",
            "非洲小叶紫檀0.8*108粒搭配狮子头送礼自戴",
            "李宁游泳包干湿分离防水袋子斜跨手提健身男泳裤收纳袋大容量泳包 753黑红色【可放拖鞋】 干湿分离",
            "李宁单肩包男包女包官方新款训练系列运动包ABDS615 黑色 150*85*200mm",
            "【附国检鉴定证书】小叶紫檀0.8*108颗蝴蝶手链男女款佛珠手串盘玩把玩文玩拍卖",
            "即势美式冲锋衣外套男女春秋季学生户外防风防水三合一飞行夹克外套男 黑色【连帽可拆6266】 XL",
            "自营易旅（Etravel） 隐形眼镜盒 便携简约隐形眼镜盒光面DIY便携式伴侣盒 奶油黄",
            "俞兆林【10双】袜子男士春夏季棉袜吸汗透气运动短袜布标男袜日系船袜学生袜浅口潮袜 外星时尚布标男袜10双装 39-43",
            "缅甸花梨龙凤呈祥果盒24*24*8.5cm经久耐用餐桌实用摆件",
            "打火机zippo纯铜限量版女士送男友煤油款砂轮防风不含气创意黄铜深雕双面极速机车",
            "特价 半钛近视眼镜框男士潮全框眼睛架可配眼镜近视镜超轻女护目镜大框镜架时尚简约商务",
            "紫光檀 雕刻虎头2.0x12颗手串 跑环 夜光石男款送礼自戴",
            "左右良品凉鞋女水晶护士洞洞鞋女2023春季新款沙滩防滑厚底孕妇果冻护士鞋 牡蛎金 37",
            "发簪黑檀木雕刻木簪古风簪子盘发古装头饰木质木制手工 弄梅 18CM",
            "纽百盾劳保鞋男士ins超火男潮老爹鞋钢包头防砸防刺穿轻便软底防臭增高安全鞋 515战斗黑【防砸防刺】【标准码】 40",
            "珂旭弹力圈珍珠手镯",
            "【新品特惠】大嘴猴（Paul Frank）保温杯马克杯套装四件套情侣组合 PFC761T 高端礼盒装",
            "Zippo正品夜光流沙打火机情人时尚礼物炫酷收藏送男友送女友抖音款5色透明外壳新潮创意",
            "印尼沉香20mm手串雕刻《六字真言》克重20g高端大气男款送礼自戴",
            "打火机zippo纯铜限量版女士送男友煤油款砂轮防风不含气创意黄铜深雕双面极速机车",
            "四季平安豆 大叶黄杨木尺寸，总长11，长4，宽2.5，厚1，厘米",
            "置衣堂袜子男士长筒袜秋冬季ins街头风运动吸汗透气学生篮球高帮长袜男字母街头 混色5双装 均码",
            "【附国检鉴定证书】小叶紫檀0.8*108颗蝴蝶手链男女款佛珠手串盘玩把玩文玩拍卖",
            "卡洛特（KLUOT）穿戴甲片 美甲贴片指甲片假指甲片可穿戴可拆卸果冻胶 穿戴甲24片 车厘子红【含工具包】",
            "GUCCI 古驰 Gucci眼镜 男士金属框架太阳眼镜 蓝色 GG1099SA 002",
            "火树 999足金黄金戒指女转运珠小金珠本命年红绳金戒指男女款情侣指环金豆豆虎年硬金属虎 金重约0.22g(送检测报告)"
        ],
        prices: [
            "189.00",
            "360.00",
            "278.00",
            "19.90",
            "30.00",
            "2199.00",
            "69.00",
            "19.80",
            "98.00",
            "150.00",
            "69.90",
            "78.00",
            "209.00",
            "108.00",
            "218.00",
            "108.00",
            "29.90",
            "400.00",
            "198.00",
            "119.00",
            "68.00",
            "69.00",
            "39.00",
            "138.00",
            "30.00",
            "189.00",
            "360.00",
            "278.00",
            "19.90",
            "30.00",
            "2199.00",
            "19.80",
            "98.00",
            "150.00",
            "69.90",
            "78.00",
            "209.00",
            "108.00",
            "218.00",
            "108.00",
            "12.90",
            "29.90",
            "400.00",
            "198.00",
            "119.00",
            "68.00",
            "69.00",
            "39.00",
            "138.00",
            "30.00",
            "189.00",
            "360.00",
            "278.00",
            "198.00",
            "30.00",
            "19.90",
            "218.00",
            "19.80",
            "2199.00",
            "150.00"
        ]
    },
    '进口好物': {
        // 进口好物
        imgs: [
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/180326/10/33269/43625/63eb57f3Fe751b5f4/0ecca0d88809f328.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/148476/33/30282/38810/638febe2E1f797389/0eada70c58bef62b.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/75916/17/21253/36154/62da5e21Efd7fbdbd/81887df2e1130487.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/55520/20/22977/65808/63d4de93F6c8a53d2/b65303802b6c1a94.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/1852/21/20642/115151/63848c5cEc36518ab/c40e95b88f97f7aa.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/190213/40/23125/47329/6253de43Eaf575a4f/fddfbf2b890918c4.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/4224/37/17774/54000/627dbd10Ecf406b51/7569f38b0f994a47.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/103137/28/31340/92533/636cac22E420ba152/7fd493cd68d12b7e.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/45173/27/18003/15523/634d0238E14c194f7/11eded8c6f79fb4f.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/64606/3/18371/47517/62947c4dEc2fbc24c/0792d5f50279ceec.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/177571/23/18313/759700/611100c6E5f3f14b2/f75be1b86ee17b7c.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/96226/1/21057/64784/61e7b184Eb73f40bb/864148e6f9c7ed46.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/96244/35/14263/68252/5e60dbf6E7b329411/26bf050542214464.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/48804/24/17365/168453/628ad859E6a30cc17/e999bc3aa86a90eb.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/57341/30/10424/48378/5d77415dE80e9630e/b68fd4dc5a89fec3.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/72030/23/18378/36971/6281f750E7d5dbdfa/b30c82305709fe22.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/210373/23/38896/21748/63f875bfF9d067fd6/4499f45a947e9a79.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/104246/15/31804/30919/64083666F1de254c3/8b4888639ec991d9.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/76073/17/19650/37356/62c292d9Ec2b71581/59ddfce9772d98a3.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/93894/6/27931/103054/63bf4e1eF91b4c4c0/be6921dfc12517a9.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/203475/18/26786/129744/64004658Fabbae093/83c8b2e35c38b061.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/101379/1/29439/69588/640e7748Fd295eba1/4c23db5ae60997e7.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/130206/19/18463/236838/5fcb0368E1409e6e4/1536ff11e452f97b.png",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/201949/33/30068/72152/640a9ce1F45fe99cd/1ec610cd91a548e8.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/194225/32/29093/106366/634e19b1Ea4292979/f197fc1e47e8503f.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/180326/10/33269/43625/63eb57f3Fe751b5f4/0ecca0d88809f328.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/148476/33/30282/38810/638febe2E1f797389/0eada70c58bef62b.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/75916/17/21253/36154/62da5e21Efd7fbdbd/81887df2e1130487.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/55520/20/22977/65808/63d4de93F6c8a53d2/b65303802b6c1a94.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/1852/21/20642/115151/63848c5cEc36518ab/c40e95b88f97f7aa.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/190213/40/23125/47329/6253de43Eaf575a4f/fddfbf2b890918c4.jpg",
            "https://img10.360buyimg.com/babel/s150x150_jfs/t1/4224/37/17774/54000/627dbd10Ecf406b51/7569f38b0f994a47.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/64606/3/18371/47517/62947c4dEc2fbc24c/0792d5f50279ceec.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/45173/27/18003/15523/634d0238E14c194f7/11eded8c6f79fb4f.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/177571/23/18313/759700/611100c6E5f3f14b2/f75be1b86ee17b7c.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/96226/1/21057/64784/61e7b184Eb73f40bb/864148e6f9c7ed46.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/103137/28/31340/92533/636cac22E420ba152/7fd493cd68d12b7e.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/96244/35/14263/68252/5e60dbf6E7b329411/26bf050542214464.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/48804/24/17365/168453/628ad859E6a30cc17/e999bc3aa86a90eb.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/57341/30/10424/48378/5d77415dE80e9630e/b68fd4dc5a89fec3.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/72030/23/18378/36971/6281f750E7d5dbdfa/b30c82305709fe22.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/210373/23/38896/21748/63f875bfF9d067fd6/4499f45a947e9a79.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/104246/15/31804/30919/64083666F1de254c3/8b4888639ec991d9.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/76073/17/19650/37356/62c292d9Ec2b71581/59ddfce9772d98a3.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/93894/6/27931/103054/63bf4e1eF91b4c4c0/be6921dfc12517a9.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/203475/18/26786/129744/64004658Fabbae093/83c8b2e35c38b061.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/101379/1/29439/69588/640e7748Fd295eba1/4c23db5ae60997e7.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/141882/11/33706/15450/63e656b2F5a5b87fb/5f8e857108694dbf.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/130206/19/18463/236838/5fcb0368E1409e6e4/1536ff11e452f97b.png",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/201949/33/30068/72152/640a9ce1F45fe99cd/1ec610cd91a548e8.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/78374/28/19188/192260/628f22afE3061384c/ca8d8344046a6f5a.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/172579/23/23677/41474/61bc233dEe5133594/b519c80f0834f020.jpg",
            "https://img11.360buyimg.com/babel/s150x150_jfs/t1/136941/22/25021/29914/6376a783Ed7aab23e/b34b861465ad1a6d.jpg",
            "https://img13.360buyimg.com/babel/s150x150_jfs/t1/62858/23/23458/29462/638c358fEb34a03a2/d57344dce4697d79.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/89054/7/27038/117403/62aae01cE4232fdfb/f2c394aaab01c172.jpg",
            "https://img14.360buyimg.com/babel/s150x150_jfs/t1/185202/24/30709/20785/63830959Eec9546fe/a48b430510cebff5.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/102588/5/33243/209747/6332b106E35970808/70b0c2c768f51e7b.jpg",
            "https://img20.360buyimg.com/babel/s150x150_jfs/t1/30527/33/19392/18990/6376a21aE50e9e318/e95bc2e0fa2272f4.jpg",
            "https://img30.360buyimg.com/babel/s150x150_jfs/t1/194225/32/29093/106366/634e19b1Ea4292979/f197fc1e47e8503f.jpg",
            "https://img12.360buyimg.com/babel/s150x150_jfs/t1/65578/27/20765/540266/62bbf2bbEdd426e4c/0e7934e14f229e4c.png"
        ],
        titles: [
            "宫中秘策（GOONGBE）温和防晒缺妆纸巾10片装 温和不刺激 天然萃取 韩国进口 温和防晒缺妆纸巾10片装*3",
            "【JD物流 日本直邮】 Frio 胰岛素冷却笔 安全携带 可重复循环使用 胰岛素冷却器无需冷藏 紫色",
            "艾罗伯特（iRobot） 【日本直邮】扫地机器人 清洁家用智能便捷拖地扫地多功能 m613860 拖地【需变压器】",
            "MODAMODA韩国进口男士女士滋养蓬松头发洗黑金箍棒焕显洗发水小样 7ml*7",
            "真露（JINRO）青葡萄味烧酒13度纯正韩国本土版果味烧酒360毫升原产国跨境直发",
            "三轮胜高田 专业制作手工拉面日本厂家原袋进口京东宁波保税仓直送日本胜高田牌三轮神丝面",
            "达亿瓦（DAIWA） DAIWA达亿瓦 TOURNAMENT ISO AGS 日本进口 钓鱼竿海钓 1.5-50・R",
            "Nimm2 德国进口 二宝维他命香橙及柠檬夹心果汁糖110g 含9种维生素水果汁硬糖儿童零食",
            "SHIMANO SHIMANO禧玛诺22新款NEWBASIS矶钓竿防波提钓竿 1-500",
            "FLUX 日本 单板滑雪固定器刻滑固定器 XF系列 WHITE/BLACK M",
            "BIRKENSTOCK软木包头拖鞋男女款绒面软底Boston系列 深棕窄版660463 37",
            "K-swiss 盖世威 RAMLI COURT 男士新款时尚现代轻便缓冲舒适运动鞋网球鞋 黑色/白色/棕色06999-049-M 39.5码/US7",
            "双立人（ZWILLING） 指甲刀金色纪念款胡须剪指甲剪眉镊美甲工具套装 蓝色牛皮五件套",
            "李施德林（LISTERINE）美国Listerine李施德林口气清新片3*24片 绿色清新薄荷味",
            "Lafancys乐芳希施蓬松宠物犬猫通用香波护毛素赛级洗护 NK-12 蓬松香波60小瓶",
            "DAIWA 达亿瓦 LANDING POLE II 矶钓便携抄网玉柄抄子 40",
            "阿迪达斯 （adidas）Stabil Next Gen 缓震支撑 轻便耐磨男士运动排球鞋 Cloud White / Team Navy B 7",
            "Blank ME blank me半分一干湿两用气垫植绒粉扑超软不吸粉1只装",
            "深蓝伏特加（SKYY VODKA）洋酒 深蓝牌 伏特加 果香 多种口味 750ml 深蓝原味*1瓶",
            "L.L.Bean/宾恩男士户外手提包保温饭盒包LOGO轻便学生包TA511136 BJ Periwinkle Sky Chevron",
            "金鸟2盒装日本防螨枕头新型除螨包床上驱螨虫贴包家用植物祛螨 除螨包(日常)",
            "施巴成人保湿水分面霜植物萃取干性敏感性肌肤5%尿素面霜孕产妇可用 控粉刺祛黑头凝胶50ml",
            "日本久光贴久光制药缓解消除颈椎肩周炎膝盖滑膜炎腱鞘炎肌肉关节腰腿疼痛 久光贴7枚*3袋",
            "YONEX尤尼克斯 羽毛球手胶 防滑 吸汗带 吸汗手感 ac140-475红 手胶",
            "Ddrops美国进口加拿大宝宝儿童维生素D3滴剂 D drops婴幼儿vd3 补钙搭档 婴幼儿童100滴600IU 1岁-18岁 1瓶",
            "宫中秘策（GOONGBE）温和防晒缺妆纸巾10片装 温和不刺激 天然萃取 韩国进口 温和防晒缺妆纸巾10片装*3",
            "【JD物流 日本直邮】 Frio 胰岛素冷却笔 安全携带 可重复循环使用 胰岛素冷却器无需冷藏 紫色",
            "艾罗伯特（iRobot） 【日本直邮】扫地机器人 清洁家用智能便捷拖地扫地多功能 m613860 拖地【需变压器】",
            "MODAMODA韩国进口男士女士滋养蓬松头发洗黑金箍棒焕显洗发水小样 7ml*7",
            "真露（JINRO）青葡萄味烧酒13度纯正韩国本土版果味烧酒360毫升原产国跨境直发",
            "三轮胜高田 专业制作手工拉面日本厂家原袋进口京东宁波保税仓直送日本胜高田牌三轮神丝面",
            "达亿瓦（DAIWA） DAIWA达亿瓦 TOURNAMENT ISO AGS 日本进口 钓鱼竿海钓 1.5-50・R",
            "FLUX 日本 单板滑雪固定器刻滑固定器 XF系列 WHITE/BLACK M",
            "SHIMANO SHIMANO禧玛诺22新款NEWBASIS矶钓竿防波提钓竿 1-500",
            "BIRKENSTOCK软木包头拖鞋男女款绒面软底Boston系列 深棕窄版660463 37",
            "K-swiss 盖世威 RAMLI COURT 男士新款时尚现代轻便缓冲舒适运动鞋网球鞋 黑色/白色/棕色06999-049-M 39.5码/US7",
            "Nimm2 德国进口 二宝维他命香橙及柠檬夹心果汁糖110g 含9种维生素水果汁硬糖儿童零食",
            "双立人（ZWILLING） 指甲刀金色纪念款胡须剪指甲剪眉镊美甲工具套装 蓝色牛皮五件套",
            "李施德林（LISTERINE）美国Listerine李施德林口气清新片3*24片 绿色清新薄荷味",
            "Lafancys乐芳希施蓬松宠物犬猫通用香波护毛素赛级洗护 NK-12 蓬松香波60小瓶",
            "DAIWA 达亿瓦 LANDING POLE II 矶钓便携抄网玉柄抄子 40",
            "阿迪达斯 （adidas）Stabil Next Gen 缓震支撑 轻便耐磨男士运动排球鞋 Cloud White / Team Navy B 7",
            "Blank ME blank me半分一干湿两用气垫植绒粉扑超软不吸粉1只装",
            "深蓝伏特加（SKYY VODKA）洋酒 深蓝牌 伏特加 果香 多种口味 750ml 深蓝原味*1瓶",
            "L.L.Bean/宾恩男士户外手提包保温饭盒包LOGO轻便学生包TA511136 BJ Periwinkle Sky Chevron",
            "金鸟2盒装日本防螨枕头新型除螨包床上驱螨虫贴包家用植物祛螨 除螨包(日常)",
            "施巴成人保湿水分面霜植物萃取干性敏感性肌肤5%尿素面霜孕产妇可用 控粉刺祛黑头凝胶50ml",
            "Apple/苹果 iPad 第九代 10.2英寸平板电脑 iPad9海外版 【WiFi版】深空灰色 64GB",
            "日本久光贴久光制药缓解消除颈椎肩周炎膝盖滑膜炎腱鞘炎肌肉关节腰腿疼痛 久光贴7枚*3袋",
            "YONEX尤尼克斯 羽毛球手胶 防滑 吸汗带 吸汗手感 ac140-475红 手胶",
            "达亿瓦（DAIWA） DAIWA达瓦 UNIT CASE UC-R SERIES 单元盒 黄绿色 600",
            "艾罗伯特（iRobot）【日本直邮 日本发货】艾罗伯特（iRobot)扫地机器人 清洁家用智能便捷拖地扫地多功能 b390060拖地【需变压器】",
            "【海外直邮】LookFantastic US|Eyeko|Eyeko Lash Alert Cush",
            "【海外直邮】Moosejaw|Mad Rock|Mad Rock Mustache Mad Pad 图片色1",
            "亚瑟士（asics）METASPEED SKY+ 男女款竞速碳板跑步鞋透气耐磨缓震回弹运动鞋 1013A115-300 松绿 标准40.5/US7.5",
            "【海外直邮】Macy's|Totes|Wo男士 Rainbow Auto-Open Stick",
            "UBISOFT 索尼 SONY PS5 女神战记 极乐净土 北欧女神 港中 *现货",
            "【海外直邮】LookFantastic US|Eyeko|Eyeko Eyelash Curlers",
            "Ddrops美国进口加拿大宝宝儿童维生素D3滴剂 D drops婴幼儿vd3 补钙搭档 婴幼儿童100滴600IU 1岁-18岁 1瓶",
            "美版Levis李维斯牛仔裤男501浅蓝色宽松直筒百搭长裤子潮流夏秋00501-2333 浅蓝色 30/32"
        ],
        prices: [
            "35.00",
            "489.00",
            "7069.00",
            "35.00",
            "16.90",
            "16.17",
            "6330.00",
            "18.00",
            "4470.00",
            "2399.00",
            "1199.00",
            "1180.00",
            "1599.00",
            "59.00",
            "57.00",
            "950.00",
            "2390.00",
            "69.00",
            "68.00",
            "539.00",
            "166.00",
            "157.00",
            "102.00",
            "70.00",
            "53.00",
            "99.00",
            "35.00",
            "489.00",
            "7069.00",
            "35.00",
            "16.90",
            "16.17",
            "6330.00",
            "2399.00",
            "4470.00",
            "1199.00",
            "1180.00",
            "18.00",
            "1599.00",
            "59.00",
            "57.00",
            "950.00",
            "2390.00",
            "69.00",
            "68.00",
            "539.00",
            "166.00",
            "157.00",
            "102.00",
            "2039.00",
            "70.00",
            "53.00",
            "45.00",
            "3919.00",
            "337.00",
            "2513.00",
            "4163.00",
            "520.00",
            "209.00",
            "264.00"
        ]
    }
}
// 为你推荐下的精选热点
let siftHot = [
    [
        "应急启动电源",
        "补水眼霜",
        "苏泊尔无烟锅",
        "打印机色带",
        "充电宝",
        "功夫茶杯",
        "汽车坐垫",
        "固态硬盘"
    ], [
        "微波炉",
        "橄榄调和油",
        "洗碗机家用",
        "防水胶",
        "面膜",
        "演唱会望远镜",
        "鳄鱼皮钱包",
        "不粘锅煎锅"
    ], [
        "美的电饭煲",
        "自动喂食器",
        "录音笔",
        "移动书架",
        "电动磨豆机",
        "润本蚊香液",
        "加湿器",
        "蜡烛香薰"
    ], [
        "遛狗绳",
        "增压花洒喷头",
        "七度空间卫生巾",
        "容声冰箱",
        "折叠床",
        "游戏方向盘",
        "按摩椅",
        "保温壶"
    ], [
        "天燃气灶双灶",
        "自拍杆",
        "开关插座",
        "珍珠胸针",
        "笔记本声卡",
        "羽毛球拍",
        "榨汁机",
        "电脑散热架"
    ]
];
//底部top  title
let footerTop = ["品类齐全，轻松购物", "多仓直发，极速配送", "正品行货，精致服务", "天天低价，畅选无忧"];
// 底部菜单数据
let footerMenuData = [
    {
        title: '购物指南',
        list: ['购物流程', '会员介绍', '生活旅行', '常见问题', '大家电', '联系客服'],
    }, {
        title: '配送方式',
        list: ['上门自提', '211限时达', '配送服务查询', '配送费收取标准'],
    }, {
        title: '支付方式',
        list: ['货到付款', '在线支付', '分期付款', '公司转账'],
    }, {
        title: '售后服务',
        list: ['售后政策', '价格保护', '退款说明', '返修/退换货', '取消订单'],
    }, {
        title: '特色服务',
        list: ['夺宝岛', 'DIY装机', '延保服务', '京东E卡', '京东通信', '京鱼座智能'],
    }
];
// 底部图片数据
let pageEndData = [
    {
        width: '103px',
        imgUrl: 'https://img10.360buyimg.com/imagetools/jfs/t1/211298/12/18097/67160/6215e091E7fb1c693/cc1d8d291ea917c0.png',
        imgPos: '-205px -111px'
    }, {
        width: '103px',
        imgUrl: 'https://img10.360buyimg.com/imagetools/jfs/t1/211298/12/18097/67160/6215e091E7fb1c693/cc1d8d291ea917c0.png',
        imgPos: '-205px -74px'
    }, {
        width: '103px',
        imgUrl: 'https://img10.360buyimg.com/imagetools/jfs/t1/211298/12/18097/67160/6215e091E7fb1c693/cc1d8d291ea917c0.png',
        imgPos: '-205px -37px'
    }, {
        width: '103px',
        imgUrl: 'https://img13.360buyimg.com/imagetools/jfs/t1/108497/17/22418/15570/6215e0d0E01387603/81e883d9e15cebb7.png',
        imgPos: '0 -66px'
    }, {
        width: '103px',
        imgUrl: 'https://img10.360buyimg.com/imagetools/jfs/t1/211298/12/18097/67160/6215e091E7fb1c693/cc1d8d291ea917c0.png',
        imgPos: '0 -155px'
    }, {
        width: '103px',
        imgUrl: 'https://img13.360buyimg.com/imagetools/jfs/t1/108497/17/22418/15570/6215e0d0E01387603/81e883d9e15cebb7.png',
        imgPos: '0 -99px'
    }, {
        width: '70px',
        imgUrl: 'https://img13.360buyimg.com/imagetools/jfs/t1/108497/17/22418/15570/6215e0d0E01387603/81e883d9e15cebb7.png',
        imgPos: '-104px -99px'
    }, {
        width: '88px',
        imgUrl: 'https://img13.360buyimg.com/imagetools/jfs/t1/108497/17/22418/15570/6215e0d0E01387603/81e883d9e15cebb7.png',
        imgPos: '-104px -131px'
    }
];
//底部第一行数据
let footerFirst=[
    "关于我们",
    "联系我们",
    "联系客服",
    "合作招商",
    "商家帮助",
    "营销中心",
    "手机京东",
    "友情链接",
    "销售联盟",
    "京东社区",
    "风险监测",
    "隐私政策",
    "京东公益",
    "Media & IR"
];
//底部第二行
let footerMidTop=[
    "京公网安备 11000002000088号 ",
    "京ICP备11041704号 ",
    "ICP ",
    "互联网药品信息服务资格证编号(京)-经营性-2014-0008 ",
    '新出发京零 字第大120007号'
];
//底部第三行
let footerMidMid=[
    "互联网出版许可证编号新出网证(京)字150号",
    "出版物经营许可证",
    "网络文化经营许可证京网文[2020]6112-1201号",
    "违法和不良信息举报电话：4006561155"
];
//底部第四行
let footerMidBot=[
    "Copyright © 2004 - 2023  京东JD.com 版权所有",
    "消费者维权热线：4006067733",
    "经营证照",
    "(京)网械平台备字(2018)第00003号",
    '营业执照',
    '增值电信业务经营许可证'
];
//底部第五行国旗方面
let footerMidWu=[
    " Сайт России ",
    " Situs Indonesia ",
    " Sitio de España ",
    " เว็บไซต์ประเทศไทย"
];

// $0.querySelectorAll('li').forEach(function (e) {
//     console.log(
//         Array.from(e.querySelectorAll("p")).map(a => {
//             return a.innerText;
//         })
//     )
// })