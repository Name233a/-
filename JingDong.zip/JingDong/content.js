const $$ = jQuery.noConflict();
navCity.forEach(function (e) {
    let li = document.createElement('li');
    let a = document.createElement("a");
    a.innerText = e;
    li.append(a);
    $$(".nav-left-hide>ul").append(li);
});
$$('.nav-left-hide>ul>li>a:first').addClass('nav-left-hide-show');
$$('.nav-left-hide>ul>li>a').addClass('nav-left-hide-ahover');
const navlHidea = document.querySelectorAll(".nav-left-hide>ul>li>a");
const cityText = document.querySelector(".nav-left>span");

// 封装city的所含代码
function cityClick() {
    $$('.nav-left-hide>ul>li>a').each(function (index, value) {
        if ($$(value).hasClass('nav-left-hide-show') == true) {
            $$(value).removeClass("nav-left-hide-ahover");
        }
    });
}

$$('.nav-left-hide').mouseenter(function () {
    cityClick();
});
$$('.nav-left-hide>ul>li>a').each(function () {
    this.onclick = function (e) {
        navlHidea.forEach(function (e) {
            e.classList.remove('nav-left-hide-show');
        });
        e.target.classList.add('nav-left-hide-show');
        $$('.nav-left-hide>ul>li>a').addClass('nav-left-hide-ahover');
        cityClick();
        cityText.innerText = e.target.innerText;
    }
});
// 网址导航隐藏页面的内容
const wzDt = document.querySelectorAll(".mywz>dl>dt");
const wzDd = document.querySelectorAll(".mywz>dl>dd");
wzDt.forEach(function (value, index) {
    value.innerText = wwdt[index];
});
wzDd.forEach(function (v, i) {
    let arr = wwdh[wzDt[i].innerText];
    for (const key in arr) {
        v.innerHTML += `<div><a href="">${arr[key]}</a></div>`;
    }

});
// input搜索框内的字
let headMidTopLinp = 0;
setInterval(function () {
    if (headMidTopLinp == inputArr.length) {
        headMidTopLinp = 0;
    }
    $$('.head-mid-top-left>input').attr('placeholder', `${inputArr[headMidTopLinp]}`);
    headMidTopLinp++;
}, 1000)

// 封装二维码显示隐藏
function erweiBlock() {
    $$(".sanjiao").css('display', 'block');
    $$(".myphone-hide").css('display', 'block');
}

function erweiNone() {
    $$(".sanjiao").css('display', 'none');
    $$(".myphone-hide").css('display', 'none');
}

// 触摸二维码显示
$$(".head-right-erweima").mouseenter(function () {
    erweiBlock();
});
// 离开二维码隐藏
$$(".head-right-erweima").mouseleave(function () {
    erweiNone();
});
// 离开二维码隐藏的页面使页面隐藏
$$(".myphone-hide").mouseleave(function () {
    erweiNone();
});
// 触摸手机京东显示
$$('.myphone').mouseenter(function () {
    erweiBlock();
});
// 离开手机京东隐藏
$$('.myphone').mouseleave(function () {
    erweiNone();
});
//全部移除文字颜色
function textShow() {
    $$(".broadside-a").each(function (i, v) {
        $$(v).removeClass('broadside-a-show');
    });
};
//侧边栏监听
$$(window).scroll(function (e) {
    console.log($$(document).scrollTop());
    if ($$(document).scrollTop() > 560) {
        $$(".broadside").addClass("broadside-show");
    };
    // 1300
    if ($$(document).scrollTop() > 1300) {
        $$('.broadside-show').css('marginTop', '70px');
    };
    if ($$(document).scrollTop() < 560) {
        $$(".broadside").removeClass("broadside-show");
        $$(".broadside").css('marginTop', '0');
    };
});
//点击滚动
$$('.broadside-a').each(function (i, v) {
    v.onclick = function (e) {
        e.preventDefault();
        textShow();
        if (i == 0) {
            $$('body,html').animate({ scrollTop: 596 }, 1000);
            $$(".broadside").css('marginTop', '0');
        } else if (i == 1) {
            $$('body,html').animate({ scrollTop: 728 }, 1000);
            $$(".broadside-a").eq(i).addClass('broadside-a-show');
        } else if (i == 2) {
            $$('body,html').animate({ scrollTop: 1390 }, 1000);
            $$(".broadside-a").eq(i).addClass('broadside-a-show');
        }
    }
});
//点机回到顶部
$$(".broadside>a").on('click', function (e) {
    e.preventDefault();
    $$('body,html').animate({ scrollTop: 0 }, 1000);
});

// 监听页面滚动
$$(window).scroll(function (e) {
    //1545
    if ($$(document).scrollTop() < 1545) {
        $$('.recommend-top').removeClass('recommend-top-fixed');
    }
    if ($$(document).scrollTop() > 1545) {
        $$('.recommend-top').addClass('recommend-top-fixed');
    }
    if ($$(document).scrollTop() > 596) {
        textShow();
        $$(".broadside-a").eq(0).addClass('broadside-a-show');
    }
    if ($$(document).scrollTop() >= 728) {
        textShow();
        $$(".broadside-a").eq(1).addClass('broadside-a-show');
    }
    if ($$(document).scrollTop() >= 1390) {
        textShow();
        $$(".broadside-a").eq(2).addClass('broadside-a-show');
    }
    // 搜索框
    if ($$(document).scrollTop() > 670) {
        $$('.header').addClass('headderPos');
        $$('.head-mid-mid,.head-mid-bot,.head-right-erweima,.logo-left img').css('display', 'none');
        $$(".logo-left").css({
            'height': 70,
            'backgroundImage': 'url(https://storage.360buyimg.com/channel2022/jd_home/0.0.9/assets/sprite/header/sprite.png)',
            'backgroundPosition': '-9px -108px',
            'backgroundRepeat': 'no-repeat'
        });
    } else if ($$(document).scrollTop() < 670) {
        $$('.header').removeClass('headderPos');
        $$('.head-mid-mid,.head-mid-bot,.head-right-erweima').css('display', 'block');
        $$('.logo-left img').css({
            'display': 'block',
            "height": 120,
        });
        $$(".logo-left").css({
            'backgroundImage': 'none',
        })
    }
});

// logo下面的小列表
for (const key in menuList) {
    let value = menuList[key].cate_menu_item;
    let li = document.createElement('li');
    for (let i = 0; i < value.length; i++) {
        let a = document.createElement('a');
        a.innerText = value[i];
        li.append(a);
        if (i == value.length - 1) {
            $$(".bd-first-left").append(li);
            continue;
        }
        let span = document.createElement("span");
        span.innerText = '/';
        li.append(span);
    }
    $$(".bd-first-left").append(li);
}


// 循环创建轮播图左边列表隐藏的盒子
for (const key in menuList) {
    let index = key;
    let right = menuList[key].right.cate_channe;
    let rTitle = menuList[key].right.cate_detail;
    right.forEach(function (e) {
        $$('.bd-fl-l-top').eq(key).append(`<a href="">${e}<i class="iconfont icon-youjiantou2"></i></a>`);
    });
    for (const key in rTitle) {
        rTitle[key].cate_detail_tit.forEach(function (e) {
            $$('.bd-fl-l-bot').eq(index).append(`
            <dl class='bd-fl-l-bot-dl'>
            <dt><a href="">${e}<i class="iconfont icon-youjiantou2"></i></a></dt>
            <dd class="bd-fl-l-bot-dd"></dd>
            </dl>
            `);
        });
    }
}


for (const key in menuList) {
    let num = 0;
    let index = key;
    let list = menuList[key].right.cate_detail;
    for (const key in list) {
        list[key].cate_detail_con.forEach(function (e) {
            $$(`.bd-fl-l-bot:eq(${index}) dd`).eq(num).append(`<a href="">${e}</a>`);
        })
        num++;
    }
}
$$(".bd-first-left li").each(function (i, v) {
    // li移入
    $$(v).on('mouseenter', function () {
        $$('.bd-first-left-listbox').css('display', 'block');
        $$(".bd-list").eq(i).css('display', 'block');
        $$(v).css('backgroundColor', '#d9d9d9');
    });
    // li移出
    $$(v).on('mouseleave', function () {
        $$('.bd-first-left-listbox').css('display', 'none');
        $$(".bd-list").eq(i).css('display', 'none');
        $$(v).css('backgroundColor', '#fefefe');
    });
});

$$(".bd-list").each(function (i, v) {
    // 移入轮播图右边列表隐藏的盒子
    $$(v).on('mouseenter', function () {
        $$('.bd-first-left-listbox').css('display', 'block');
        $$(v).css('display', 'block');
        $$('.bd-first-left li').eq(i).css('backgroundColor', '#d9d9d9')
    });
    // 移出轮播图右边列表隐藏的盒子
    $$(v).on('mouseleave', function () {
        $$('.bd-first-left li').each(function (i, v) {
            $$(v).css('backgroundColor', '#fefefe');
        });
        $$('.bd-first-left-listbox').css('display', 'none');
        $$(v).css('display', 'none');
    });
});
// 轮播图
var mySwiper = new Swiper('.swiper1', {
    direction: 'horizontal', loop: true, // 循环模式选项
    effect: 'fade', // 如果需要分页器
    pagination: {
        el: '.swiper-pagination',
    }, navigation: {
        nextEl: '.b', prevEl: '.a',
    }, autoplay: {
        delay: 2000, stopOnLastSlide: false, disableOnInteraction: false, pauseOnMouseEnter: true,
    },
});
//如果你在swiper初始化后才决定使用clickable，可以这样设置
mySwiper.params.pagination.clickable = true;
//此外还需要重新初始化pagination
mySwiper.pagination.destroy();
mySwiper.pagination.init();
mySwiper.pagination.bullets.eq(0).addClass('swiper-pagination-bullet-active');
//鼠标滑过pagination控制swiper切换
for (i = 0; i < mySwiper.pagination.bullets.length; i++) {
    mySwiper.pagination.bullets[i].onmouseover = function () {
        this.click();
    };
}
var mySwipers = new Swiper('.swiper2', {
    direction: 'horizontal', loop: true, // 循环模式选项
    effect: 'fade', navigation: {
        nextEl: '.swiperr', prevEl: '.swiperl',
    }, autoplay: {
        delay: 2000, stopOnLastSlide: false, disableOnInteraction: false, pauseOnMouseEnter: true,
    },
});
// 轮播图右边最下面的图标循环创建
bodyrListImg.iconTitle.forEach(function (v, i) {
    let li = document.createElement("li");
    let a = document.createElement("a");
    a.classList.add('bd-r-bot-ul-a');
    let i1 = document.createElement("img");
    let span = document.createElement("span");
    i1.src = bodyrListImg.beforIcon[i];
    a.append(i1);
    let i2 = document.createElement("img");
    i2.classList.add('bd-r-bot-ul-img2');
    i2.src = bodyrListImg.afterIocn[i];
    a.append(i2);
    span.innerText = v;
    a.append(span);
    li.append(a);
    $$(".bd-r-bot ul").append(li);
});

// 倒计时的js
function countDown() {
    let span = document.querySelectorAll('.ms-count-down span');
    const startTimeSpan = document.querySelector('.start-time');
    // 获取当前的场次（2H一场）
    const startTime = new Date();
    // 设置分秒毫秒为0，同时设置小时为偶数时
    startTime.setHours(startTime.getHours() - startTime.getHours() % 2, 0, 0, 0// 基数时减1，偶数时不减
    );
    // 设置开场时间
    startTimeSpan.innerText = startTime.getHours() > 10 ? startTime.getHours() : '0' + startTime.getHours();
    // 设置结束时间
    startTime.setHours(startTime.getHours() + 2);

    function start() {
        // 现在的时间
        const nowTime = new Date();
        // 计算当前时间和结束时间的时间差
        const cha = startTime - nowTime;
        // 根据时间差的时间戳计算对应的时间
        const hour = parseInt(cha / 1000 / 60 / 60);
        const minute = parseInt(cha / 1000 / 60 % 60);
        const second = parseInt(cha / 1000 % 60);
        // 设置时间
        span[0].innerText = hour >= 10 ? hour : '0' + hour;
        span[1].innerText = minute >= 10 ? minute : '0' + minute;
        span[2].innerText = second >= 10 ? second : '0' + second;
    }

    start();
    // 开始倒计时
    setInterval(start, 1000);
}

countDown();
// 手动轮播图创建盒子
let headLbNum = 1;
let headLb;
msLb.forEach(function (v, i) {
    if (headLbNum == 1) {
        headLb = document.createElement("div");
        headLb.className = 'swiper-slide head-lb-list';
    }
    let div1 = document.createElement('div');
    let img = document.createElement("img");
    let headLbListHide = document.createElement('div');
    headLbListHide.classList.add('head-lb-list-hide')
    img.src = v.img;
    div1.append(img);
    div1.append(headLbListHide);
    let h6 = document.createElement("h6");
    h6.classList.add('head-lb-list-h6')
    h6.innerText = v.jie;
    div1.append(h6);
    let div2 = document.createElement("div");
    div2.innerText = v.jia;
    div1.append(div2);
    headLbNum++;
    headLb.append(div1);
    if (headLbNum == 5) {
        $$('.swiper3>.swiper-wrapper').append(headLb);
        headLbNum = 1;
    }
});
// 手动轮播
let mySwiper3 = new Swiper('.swiper3', {
    direction: 'horizontal', loop: true, // 循环模式选项,
    navigation: {
        nextEl: '.headR', prevEl: '.headL',
    }
});
// 频道广场
for (const key in channeData) {
    if (key < 2) {
        $$('.channel-con-bot').append(`<li class='channel-con-bot-li channel-con-bot-lis'><img src="" alt="">
        <div class="channel-con-bot-imgboxs-img-hide"></div>
        </li>`);
    } else {
        $$('.channel-con-bot').append(`<li class='channel-con-bot-li'>
        <a href="">
            <span></span>
            <span></span>
        </a>
        <div class="channel-con-bot-imgboxs">
        <div class="channel-con-bot-imgboxs-img">
                <img src="" alt="">
                <div class="channel-con-bot-imgboxs-img-hide"></div>
        </div>
        <div class="channel-con-bot-imgboxs-img">
                <img src="" alt="">
                <div class="channel-con-bot-imgboxs-img-hide"></div>
        </div>
        </div>
    </li>`);
    }

    if (key > 1) {
        channeData[key].tit.forEach(function (e, i) {
            $$(`.channel-con-bot-li:eq(${key}) span`).eq(i).text(e);
        });
    }
    channeData[key].src.forEach(function (e, i) {
        $$(`.channel-con-bot-li:eq(${key}) img`).eq(i).attr('src', `${e}`);
    });
}

// 为你推荐title
pushSellTitData.forEach(function (e, i) {
    $$('.recommend-top>ul').append(`<li></li>`);
    $$('.recommend-top>ul>li').eq(i).attr('num', `${i}`);
    e.forEach(function (v, index) {
        if (index == 0) {
            $$('.recommend-top>ul>li').eq(i).append(`<div><span class='recommend-top-li-span'>${v}</span></div>`).attr('num', `${i}`);
        } else {
            $$('.recommend-top>ul>li').eq(i).append(`<div class='recommend-li-div2'>${v}</div>`).attr('num', `${i}`);
        }
    });
    if (i == 5) {
        return;
    }
    $$('.recommend-top>ul>li').eq(i).append(`<div class='recommend-top-li-xian'></div>`);
});
$$(`.recommend-top-li-span:eq(${0})`).addClass('recommend-top-li-titshow');
$$(`.recommend-top>ul>li>div:eq(${1})`).addClass('recommend-top-li-titshow2');
// 为你推荐title点击
$$('.recommend-top>ul>li').each(function (i, v) {
    $$(v).on('click', function (e) {
        // 给所有ul隐藏
        $$('.recommend-shop>ul').each(function (i, v) {
            $$(v).css('display', 'none');
        });
        // 遍历给所有的颜色去除
        $$('.recommend-top>ul>li').each(function (index, value) {
            $$(value.querySelectorAll('span')).removeClass('recommend-top-li-titshow');
            $$(value.querySelectorAll('.recommend-li-div2')).removeClass('recommend-top-li-titshow2');
        });
        $$(v.querySelector('span')).addClass('recommend-top-li-titshow');
        $$(v.querySelector('.recommend-li-div2')).addClass('recommend-top-li-titshow2');
        $$('.recommend-shop>ul').eq(`${$$(v).attr('num')}`).css('display', 'block');
    });
});
// 为你推荐
let recommendShopNum = 0;
let recommendShopLiNum = 0;
for (const key in pushSellData) {
    $$('.recommend-shop').append("<ul class='clearfix'></ul>");
    // 渲染所有商品盒子
    for (let i = 0; i < pushSellData['精选'].imgs.length; i++) {
        $$('.recommend-shop>ul').eq(recommendShopNum).append(`<li class='recommend-shop-list'>
        <div class="recommend-shop-li-hide">
            <span class="recommend-shop-li-hide-off"></span>
            <div class="recommend-shop-li-hide-text">
                <div>
                    <i class="iconfont icon-yanjing"></i>
                    <span>找相似</span>
                </div>
            </div>
        </div>
        </li>`);
        if (i % 10 == 0 && i != 0 && key == '精选') {
            $$('.recommend-shop ul').eq(0).append("<li class='sift-hot'></li>")
        }
    }
    let item = pushSellData[key];
    for (const key in item) {
        item[key].forEach(function (v) {
            if (key === 'imgs') {
                $$(`.recommend-shop ul:eq(${recommendShopNum}) .recommend-shop-list`).eq(recommendShopLiNum).append(`
                <div class='recommend-shop-imgbox'>
                    <img src="${v}" alt="">
                    <div class="recommend-shop-img-hide"></div>
                </div>
                `);
            } else if (key === 'titles') {
                if (v.indexOf('自营') !== -1) {
                    $$(`.recommend-shop ul:eq(${recommendShopNum}) .recommend-shop-list`).eq(recommendShopLiNum).append(`
                <div class="recommend-shop-tit">
                    <p>${v.replace('自营', '<i>自营</i>')}</p>
                </div>
                `);
                } else {
                    $$(`.recommend-shop ul:eq(${recommendShopNum}) .recommend-shop-list`).eq(recommendShopLiNum).append(`
                <div class="recommend-shop-tit">
                    <p>${v}</p>
                </div>
                `);
                }
            } else if (key === 'prices') {
                if (v.indexOf('.') !== -1) {
                    let money = v.slice(`${v.length - 3}`);
                    $$(`.recommend-shop ul:eq(${recommendShopNum}) .recommend-shop-list`).eq(recommendShopLiNum).append(`
                    <div class='recommend-shop-price'>
                        <i>¥</i>
                        <span>${v.replace(`${money}`, `<span class="recommend-shop-smallprice">${money}</span>`)}</span>
                    </div>
                `);
                } else {
                    $$(`.recommend-shop ul:eq(${recommendShopNum}) .recommend-shop-list`).eq(recommendShopLiNum).append(`
                    <div class='recommend-shop-price'>
                        <i>¥</i>
                        <span>${v}</span>
                    </div>
                `);
                }
            }
            recommendShopLiNum++;
            if (recommendShopLiNum >= pushSellData['精选'].imgs.length) {
                recommendShopLiNum = 0;
            }
        })
    }
    recommendShopNum++;
}

//精选热点
$$(`.sift-hot`).each(function (i, v) {
    $$(v).append(`<div><p>精选热点</p></div><ul></ul>`);
    siftHot[i].forEach(function (e) {
        $$(`.sift-hot>ul:eq(${i})`).append(`<li>${e}</li>`);
    });
});

//底部
footerTop.forEach(function (v) {
    $$('.footer-top>ul').append(`
    <li>
        <div>
            <div class="footer-top-imgbox"></div>
            <p>${v}</p>
        </div>
    </li>
`)
});
$$(".footer-top-imgbox").eq(0).css("backgroundPosition", "0 -192px");
$$(".footer-top-imgbox").eq(1).css("backgroundPosition", "-41px -192px");
$$(".footer-top-imgbox").eq(2).css("backgroundPosition", "-82px -192px");
$$(".footer-top-imgbox").eq(3).css("backgroundPosition", "-123px -192px");

//底部列表
footerMenuData.forEach(function (e, i) {
    $$(".footer-mid-l").append(`<dl><dt><h5>${e.title}</h5></dt></dl>`);
    e.list.forEach(function (v) {
        $$(`.footer-mid-l>dl:eq(${i})`).append(`<dd><a href="">${v}</a></dd>`);
    })
});
$$(".footer-mid-l").append(`<dl>
    <dt><h5>京东自营覆盖区县</h5></dt>
        <dd>
            <p>京东已向全国2661个区县提供自营配送服务，支持货到付款、POS机刷卡和售后上门服务。</p>
            <a href="">查看详情 ></a>
        </dd>
</dl>`);
//最底部第一行
footerFirst.forEach(function (v, i) {
    if (i == footerFirst.length - 1) {
        $$(".footr-bot-top").append(`<a href="">${v}</a>`);
        return;
    }
    $$(".footr-bot-top").append(`<a href="">${v}</a><span>|</span>`);
});
//底部第二行
footerMidTop.forEach(function (v, i) {
    if (i == footerMidTop.length - 1) {
        $$(".footr-bot-mid>p").eq(0).append(`<span>${v}</span>`);
        return;
    }
    $$(".footr-bot-mid>p").eq(0).append(`<a href="">${v}</a><span>|</span>`);
});
//底部第三行
footerMidMid.forEach(function (v, i) {
    if (i == footerMidMid.length - 1) {
        $$(".footr-bot-mid>p").eq(1).append(`<span>${v}</span>`);
        return;
    } else if (i > 0 && i < 3) {
        $$(".footr-bot-mid>p").eq(1).append(`<a href="">${v}</a><span>|</span>`);
    } else {
        $$(".footr-bot-mid>p").eq(1).append(`<span>${v}</a><span>|</span>`);
    }
});
//底部第四行
footerMidBot.forEach(function (v, i) {
    if (i == footerMidBot.length - 1) {
        $$(".footr-bot-mid>p").eq(2).append(`<a href="">${v}</a>`);
        return;
    } else if (i != 0 && i % 2 == 0) {
        $$(".footr-bot-mid>p").eq(2).append(`<a href="">${v}</a><span>|</span>`);
    } else {
        $$(".footr-bot-mid>p").eq(2).append(`<span>${v}</a><span>|</span>`);
    }
});
//底部第五行
footerMidWu.forEach(function (v, i) {
    if (i == footerMidWu.length - 1) {
        $$(".footer-guoqi").append(`<a href=""><i></i>${v}</a>`);
        return;
    }
    $$(".footer-guoqi").append(`<a href=""><i></i>${v}</a><span>|</span>`);
});
for (let i = 0; i < 8; i++) {
    $$(".footer-footer").append(`<a href=""></a>`);
}